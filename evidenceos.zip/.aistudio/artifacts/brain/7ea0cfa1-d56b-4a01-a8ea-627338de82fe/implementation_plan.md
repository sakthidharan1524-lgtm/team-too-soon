# EvidenceOS — AI-Powered OCR & Financial Document Extraction System

Implement a complete, production-ready server-side OCR and financial document extraction pipeline powered by the Gemini API (`@google/genai`) and connect it directly to the existing EvidenceOS frontend without altering its design. Extracted structured financial JSON is validated and stored on the backend for downstream reconciliation, graph construction, and anomaly investigation modules, while keeping the Upload interface clean and focused.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The architectural choices below incorporate your answers from our clarification step and govern the implementation. Please review and approve before code changes begin.

- **Confirmed Decision 1 — Backend-Stored OCR Results (Hidden by Default)**: Extracted OCR text and structured financial JSON are stored on the backend rather than rendered directly inside the Upload Documents dashboard. The frontend displays concise extraction status, stored document references, and warning/review indicators, with an optional on-demand inspection drawer only if an operator chooses to inspect/correct flagged fields or export JSON.
- **Confirmed Decision 2 — Manual Push to Evidence Ledger**: Extracted (and optionally user-corrected) financial records remain in backend OCR storage until the user clicks a manual **Add to Evidence Ledger** button, preserving separation between raw OCR ingestion and active investigation state.
- **Confirmed Decision 3 — Model Strategy**: Server attempts `gemini-3.5-flash-lite` first and automatically falls back to `gemini-3.1-flash-lite` if the primary model returns a `404` / unsupported model error, reporting the actual model executed in the response metadata.
- **Confirmed Decision 4 — MVP File & Page Limits**: Enforce configurable server limits defaulting to **15 MB max file size** and **20 pages max per PDF**, validating file extension, MIME type, binary magic-byte signature, and PDF structural integrity before processing.

---

## 1. Overview & Core Concept

- **What It Does**: Adds an Express server-side OCR ingestion and extraction engine to EvidenceOS that accepts MSME financial documents (handwritten ledgers, handwritten bills/receipts, printed invoices, bank statements, scanned PDFs, and text-based PDFs), extracts original-script text (preserving English, Tamil, and Hindi without translation), converts financial details into a strict, validated JSON schema, and stores the structured output in a backend repository ready for downstream EvidenceOS modules.
- **Target Audience / Persona**: Financial investigators, credit analysts, and MSME auditors who upload heterogeneous paper/digital records and rely on accurate, audit-safe structured data without hallucinated numbers.
- **Key Value**: Eliminates brittle client-side heuristics and delivers audit-grade, schema-validated financial extraction with explicit qualitative readability flags (`clear`, `uncertain`, `illegible`), zero silent empty extractions on scanned PDFs, and strict separation between immutable raw OCR output and manual corrections.

---

## 2. User Experience & Visual Design

### Existing Frontend Preservation
The existing EvidenceOS dark navy-slate aesthetic (`#060d1f` canvas, `#0b152b` primary panels, `#0e1933` inset controls, `#34d399` emerald primary CTA, `#f59e0b` amber warnings, `#f87171` crimson alerts), typography (`Plus Jakarta Sans` display, `DM Sans` body, `JetBrains Mono` with `tabular-nums`), top 3-zone navigation bar, 70/30 Investigation workspace, Evidence Ledger, and Anomalies views remain completely intact.

### Key User Flow (Upload Documents View)
1. **No File Selected**: Existing Upload Documents dropzone and categorized slots (**Transaction History**, **Order Copy**, **Bill / Invoice**, **WhatsApp & Other Documents**) remain unchanged, alongside the right-hand preview cards (**Graph Errors & Loops**, **Credit Score**, **Fraud Scenario Simulator**).
2. **File Selected**: Selecting or dropping an image (`JPG`, `JPEG`, `PNG`, `WEBP`) or `PDF` displays the filename, compact thumbnail preview (for images) or PDF page/size badge, and a clean document-type selector (`Auto-detect`, `Handwritten Ledger`, `Invoice`, `Receipt`, `Bank Statement`, `Transaction Document`).
3. **Uploading & Extracting**: Clicking **Extract & Store** (or running analysis on uploaded files) transitions cleanly through real, non-faked states (`Uploading` → `Extracting`) with an indeterminate loading indicator—never displaying fabricated percentage progress bars.
4. **Stored Completion State (`Completed` / `Partial Extraction` / `Failed`)**:
   - Raw OCR text and JSON are **not** dumped onto the Upload page. Instead, each processed document shows a compact status line (`Stored on backend · DOC-xxxx`, page count, detected languages, and warning/manual-review flag count when uncertain or illegible fields exist).
   - A manual **Add to Evidence Ledger** button pulls the stored financial records into the Evidence Ledger tab on demand.
   - An optional compact **Review / Export** modal trigger allows investigators—only when explicitly clicked—to preview the original file, inspect raw text/records, correct flagged fields (saved separately on the backend without overwriting raw OCR), or copy/download the stored JSON.
   - Error states (unsupported file, oversized file, corrupted document, API key issue, rate limit, or service failure) render clear, actionable inline messages without exposing stack traces.

---

## 3. Key Product Decisions & Trade-Offs

- **Backend Storage for Downstream Consumption**:
  - *Chosen Approach*: Store validated extraction payloads and separate user-correction overlays in a dedicated server-side repository exposed via clean internal REST endpoints (`POST /api/ocr/extract`, `GET /api/ocr/documents`, `GET /api/ocr/documents/:id`, `PATCH /api/ocr/documents/:id/corrections`, `DELETE /api/ocr/documents/:id`), while immediately deleting raw temporary uploads and remote Gemini File API artifacts after extraction.
  - *Why*: Meets your requirement that OCR results live on the backend for downstream reconciliation, entity matching, graph construction, and anomaly detection, while respecting security and privacy constraints by never retaining sensitive raw uploaded binaries permanently.
  - *Alternatives Considered*: Keeping OCR JSON only in browser React state (rejected because downstream backend modules could not consume it and results would be lost on reload).

- **Two-Stage PDF Extraction with Automatic PDF.js Image Fallback**:
  - *Chosen Approach*: Upload PDFs through the Gemini File API (cleaning up the remote file in a `finally` block) for native multipage document understanding. Validate page coverage and non-empty text; if native PDF processing fails or returns empty content for a non-empty scanned PDF, render pages via PDF.js into raster images on the server and process them in small page batches through Gemini, preserving exact page numbers.
  - *Why*: Ensures scanned, skewed, or handwritten multipage PDFs never silently succeed with blank text, while keeping native text/mixed PDFs fast and token-efficient.
  - *Alternatives Considered*: Always rasterizing every PDF page (slower and higher latency for clean digital bank statements) or relying only on native PDF upload (risks empty output on difficult scans).

- **Strict Accuracy Prompting + Post-Extraction Schema Validator**:
  - *Chosen Approach*: Combine Gemini structured JSON output (`responseMimeType: "application/json"` + strict `Type` schema) with a deterministic server-side validator enforcing required keys, decimal-string monetary normalization (`"5000.00"` or `null` when uncertain), valid page numbers, non-empty supporting `evidenceText`, preserved original script (English/Tamil/Hindi), and manual-review flags for `uncertain` or `illegible` values.
  - *Why*: Financial downstream analysis cannot tolerate invented numbers, flipped debit/credit signs, or grand totals double-counted as transactions.

- **Immutable Raw OCR + Separate Corrections Overlay**:
  - *Chosen Approach*: Store the original Gemini extraction payload immutably and persist any user field edits in a separate `userCorrections` collection keyed by document ID and record index.
  - *Why*: Preserves full forensic auditability so downstream systems can inspect both original OCR output and human-verified overrides.

---

## 4. Technical Architecture & Data Strategy

### System Architecture & Data Flow

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        EvidenceOS React Frontend                           │
│                                                                            │
│  ┌──────────────────────────────┐     ┌────────────────────────────────┐   │
│  │   Upload Documents Panel     │     │    Optional Review Modal       │   │
│  │  • File preview & type hint  │────▶│  • Triggered only on click     │   │
│  │  • Real status states        │     │  • Inspect / edit / export JSON│   │
│  │  • Stored ID & warning badge │     │  • Saves separate corrections  │   │
│  │  • [Add to Evidence Ledger]  │     └────────────────────────────────┘   │
│  └──────────────┬───────────────┘                      │                   │
│                 │ multipart/form-data                  │ PATCH corrections │
│                 │ POST /api/ocr/extract                │ GET stored JSON   │
│                 ▼                                      ▼                   │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │        OCR Result Adapter  ──(manual button)──▶  Evidence Ledger     │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────┬──────────────────────────────────────┬───────────────────┘
                  │                                      │
                  ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│               Express Full-Stack Server (Port 3000 + Vite)                 │
│                                                                            │
│  ┌──────────────────────┐    ┌──────────────────────────────────────────┐  │
│  │    OCR API Router    │───▶│             File Validator               │  │
│  │  • POST /extract     │    │  • Extension & MIME allowlist            │  │
│  │  • GET /documents    │    │  • Magic-byte signature inspection       │  │
│  │  • PATCH /corrections│    │  • 15 MB size & 20-page PDF enforcement  │  │
│  └──────────┬───────────┘    └────────────────────┬─────────────────────┘  │
│             │                                     ▼                        │
│             │                 ┌─────────────────────────────────────────┐  │
│             │                 │          Document Processor             │  │
│             │                 │  • Images: inline multimodal payload    │  │
│             │                 │  • PDFs: Gemini File API + cleanup      │  │
│             │                 │  • Scanned fallback: PDF.js page batch  │  │
│             │                 └───────────────────┬─────────────────────┘  │
│             │                                     ▼                        │
│             │                 ┌─────────────────────────────────────────┐  │
│             │                 │          Gemini OCR Service             │  │
│             │                 │  • Server-only process.env.GEMINI_API_KEY  │
│             │                 │  • gemini-3.5-flash-lite → fallback     │  │
│             │                 │    gemini-3.1-flash-lite on 404         │  │
│             │                 │  • Structured JSON Schema + retries     │  │
│             │                 │  • Post-parse accuracy & null validator │  │
│             │                 └───────────────────┬─────────────────────┘  │
│             │                                     ▼                        │
│             │                 ┌─────────────────────────────────────────┐  │
│             └────────────────▶│     Backend OCR Extraction Store        │  │
│                               │  • Immutable raw extraction JSON        │  │
│                               │  • Separate userCorrections overlay     │  │
│                               │  • Ready for downstream graph/reconcile │  │
│                               └─────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **Stored OCR Envelope (Backend)**:
  - `document`: `{ documentId, fileName, mimeType, fileSizeBytes, fileKind, pageCount, uploadedAt, documentTypeHint }`
  - `extraction`: Normalized financial extraction payload containing `documentId`, `fileName`, `documentType`, `detectedLanguage`, `pageCount`, `extractionStatus` (`completed` | `partial` | `failed`), `pages[]`, `parties[]`, `financialRecords[]`, `invoiceDetails`, `warnings[]`, and `reviewRequired`.
  - `userCorrections`: Separate map of field-level manual edits (`recordIndex`, `field`, `correctedValue`, `updatedAt`) that never mutates `extraction`.
  - `meta`: `{ processingTimeMs, model, fallbackUsed, extractionMethod }` (`native_image` | `native_pdf` | `pdfjs_fallback`).
- **Frontend Upload Session State**:
  - Tracks per-document lifecycle strictly using real states: `idle` (no file selected), `selected` (file chosen, preview ready), `uploading`, `extracting`, `completed`, `partial`, or `failed` (with sanitized error message), plus `addedToLedger` boolean for the manual Evidence Ledger push action.

### Interactive Component & State Mapping
- **File Drop / Browse & Category Slots**: Validates client-side accept types (`JPG`, `JPEG`, `PNG`, `WEBP`, `PDF`, plus existing `.csv`/`.txt` support), creates a local object URL preview for images (revoked on removal/unmount), and attaches a document-type hint.
- **Extract Action**: Submits `multipart/form-data` (`file`, optional `documentType`) to `POST /api/ocr/extract`, transitions state through `uploading` → `extracting`, stores the backend summary reference on completion, and surfaces warnings or failure messages inline.
- **Manual Push to Evidence Ledger**: Uses `ocrResultAdapter` to fetch/convert the backend-stored extraction (merging any separate `userCorrections`) into `EvidenceRecord` entries and appends them to the Evidence Ledger with a clear confirmation state.
- **On-Demand Review & Export Modal**: Opened only when a user clicks **Review / Export** on a stored document; lets them view the preview, inspect raw text & structured records with uncertain/illegible highlights, save separate field corrections to `PATCH /api/ocr/documents/:id/corrections`, or copy/download the validated JSON.

### Verification & Test Coverage Strategy
After implementation, the server and OCR pipeline will be verified directly against all required scenarios using synthetic test fixtures:
1. Clear printed invoice image (supplier, buyer, invoice number, date, line items, grand total).
2. Handwritten accounting ledger image (individual entries, dates, amounts, debit/credit direction, unclear handwriting flagged).
3. Scanned bank statement PDF (multipage rows, dates, descriptions, debit/credit, balances, page references, exercising PDF.js fallback if needed).
4. Blurry handwritten document (partial extraction with `uncertain`/`illegible` flags and `amountNormalized: null` instead of guessed numbers).
5. Corrupted or unsupported file (rejected cleanly by magic-byte / MIME / size validation with structured 4xx error and zero crash).
6. Multipage PDF (exact page numbering preserved with zero duplicated or dropped pages).
