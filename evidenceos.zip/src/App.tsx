import { useMemo, useState } from 'react';
import { TopBar, type WorkspaceTab } from './components/TopBar';
import { FinancialRelationshipGraph } from './components/FinancialRelationshipGraph';
import { LoanRiskFactorsPanel } from './components/LoanRiskFactorsPanel';
import { GraphErrorsPanel } from './components/GraphErrorsPanel';
import { FraudSimulatorPanel } from './components/FraudSimulatorPanel';
import { UploadWorkspace } from './components/UploadWorkspace';
import { EvidenceLedgerView } from './components/EvidenceLedgerView';
import { AnomaliesDetailView } from './components/AnomaliesDetailView';
import {
  computeSimulationMetrics,
  DEMO_UPLOAD_DOCUMENTS,
  SAMPLE_CASE,
} from './data/sampleCase';
import { buildCaseFromUploads } from './utils/documentParser';
import type {
  AnomalyFinding,
  EvidenceRecord,
  InvestigationCase,
  UploadedDocument,
} from './types/investigation';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('investigation');
  const [activeCase, setActiveCase] = useState<InvestigationCase | null>(
    SAMPLE_CASE
  );
  const [stagedDocs, setStagedDocs] = useState<UploadedDocument[]>(
    DEMO_UPLOAD_DOCUMENTS
  );
  const [customRecords, setCustomRecords] = useState<EvidenceRecord[]>([]);

  // Graph & inspection state
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [highlightLoop, setHighlightLoop] = useState<boolean>(false);
  const [ledgerNodeFilter, setLedgerNodeFilter] = useState<string | null>(null);
  const [selectedAnomalyId, setSelectedAnomalyId] = useState<string | null>(
    SAMPLE_CASE.anomalies[0].id
  );

  // Simulator state: slider defaults to 15% (matching Screenshot 1 preview),
  // appliedFakePct defaults to 0% so baseline gauges show 78/72/48/36 and Overall 68/100 until user clicks "Recalculate graph"
  const [sliderPct, setSliderPct] = useState<number>(15);
  const [appliedFakePct, setAppliedFakePct] = useState<number>(0);

  // Extraction progress state for Upload -> Investigation transition
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStage, setAnalysisStage] = useState<string>('');

  const appliedMetrics = useMemo(() => {
    const baseCase = activeCase ?? SAMPLE_CASE;
    return computeSimulationMetrics(
      baseCase.baseFactors,
      baseCase.baseOverallScore,
      appliedFakePct
    );
  }, [activeCase, appliedFakePct]);

  const previewMetrics = useMemo(() => {
    const baseCase = activeCase ?? SAMPLE_CASE;
    return computeSimulationMetrics(
      baseCase.baseFactors,
      baseCase.baseOverallScore,
      sliderPct
    );
  }, [activeCase, sliderPct]);

  const handlePrimaryHeaderAction = () => {
    if (activeCase) {
      // Start a brand-new empty investigation (shows exact Screenshot 2 empty state)
      setActiveCase(null);
      setStagedDocs([]);
      setCustomRecords([]);
      setSelectedNodeId(null);
      setHighlightLoop(false);
      setLedgerNodeFilter(null);
      setSliderPct(15);
      setAppliedFakePct(0);
      setActiveTab('upload');
    } else {
      // Reload the rich sample case immediately
      setStagedDocs(DEMO_UPLOAD_DOCUMENTS);
      setCustomRecords([]);
      setActiveCase(SAMPLE_CASE);
      setSliderPct(15);
      setAppliedFakePct(0);
      setActiveTab('investigation');
    }
  };

  const handleAddDocuments = (
    docs: UploadedDocument[],
    extracted: EvidenceRecord[]
  ) => {
    setStagedDocs((prev) => [...prev, ...docs]);
    if (extracted.length > 0) {
      setCustomRecords((prev) => [...extracted, ...prev]);
    }
  };

  const handleRemoveDocument = (docId: string) => {
    setStagedDocs((prev) => prev.filter((d) => d.id !== docId));
  };

  const handleLoadDemoBundle = () => {
    setStagedDocs(DEMO_UPLOAD_DOCUMENTS);
  };

  const handleStartAnalysis = () => {
    const docsToAnalyze =
      stagedDocs.length > 0 ? stagedDocs : DEMO_UPLOAD_DOCUMENTS;
    if (stagedDocs.length === 0) {
      setStagedDocs(DEMO_UPLOAD_DOCUMENTS);
    }

    setIsAnalyzing(true);
    setAnalysisStage('Parsing transaction ledgers and WhatsApp exports...');

    window.setTimeout(() => {
      setAnalysisStage('Mapping counterparties and verifying GST invoices...');
    }, 450);

    window.setTimeout(() => {
      setAnalysisStage('Scanning network for circular loops and risk scores...');
    }, 900);

    window.setTimeout(() => {
      const built = buildCaseFromUploads(docsToAnalyze, customRecords);
      setActiveCase(built);
      setAppliedFakePct(0);
      setSliderPct(15);
      setSelectedNodeId(null);
      setHighlightLoop(false);
      setIsAnalyzing(false);
      setActiveTab('investigation');
    }, 1350);
  };

  const handleRefreshGraph = () => {
    if (!activeCase) return;
    const nowStr = new Date().toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    setActiveCase({ ...activeCase, lastUpdated: nowStr });
  };

  const handleRecalculateGraph = () => {
    setAppliedFakePct(sliderPct);
    if (sliderPct >= 15) {
      setHighlightLoop(true);
    }
  };

  const handleResetSimulation = () => {
    setAppliedFakePct(0);
    setSliderPct(15);
    setHighlightLoop(false);
  };

  const handleUpdateAnomalyStatus = (
    anomalyId: string,
    status: AnomalyFinding['reviewStatus']
  ) => {
    if (!activeCase) return;
    setActiveCase({
      ...activeCase,
      anomalies: activeCase.anomalies.map((a) =>
        a.id === anomalyId ? { ...a, reviewStatus: status } : a
      ),
    });
  };

  const handleInspectNodeInLedger = (nodeId: string) => {
    setLedgerNodeFilter(nodeId);
    setActiveTab('ledger');
  };

  const handleFocusNodeFromPanel = (nodeId: string) => {
    setSelectedNodeId(nodeId);
    setHighlightLoop(nodeId === 'sup-203' || nodeId === 'cust-1038');
  };

  const handleViewAnomalyDetails = (anomalyId: string) => {
    setSelectedAnomalyId(anomalyId);
    setActiveTab('anomalies');
  };

  const handleLocateFromSubView = (nodeId: string, shouldHighlightLoop = false) => {
    setSelectedNodeId(nodeId);
    setHighlightLoop(shouldHighlightLoop);
    setActiveTab('investigation');
  };

  // If user switches to Investigation/Ledger/Anomalies while no analysis is loaded,
  // gently show the Upload workspace so there is never a broken/empty screen.
  const showEmptyUploadFallback = activeTab !== 'upload' && !activeCase;

  return (
    <div className="min-h-screen bg-[#060d1f] text-slate-100 flex flex-col">
      <TopBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        hasAnalysis={Boolean(activeCase)}
        onPrimaryAction={handlePrimaryHeaderAction}
      />

      <main className="mx-auto w-full max-w-[1600px] flex-1 px-4 py-5 sm:px-6 lg:px-8">
        {activeTab === 'upload' || showEmptyUploadFallback ? (
          <UploadWorkspace
            documents={stagedDocs}
            hasActiveAnalysis={Boolean(activeCase)}
            isAnalyzing={isAnalyzing}
            analysisStage={analysisStage}
            onAddDocuments={handleAddDocuments}
            onRemoveDocument={handleRemoveDocument}
            onLoadDemoBundle={handleLoadDemoBundle}
            onStartAnalysis={handleStartAnalysis}
            onOpenInvestigation={() => setActiveTab('investigation')}
          />
        ) : activeTab === 'investigation' && activeCase ? (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,7fr)_minmax(0,3fr)] items-stretch">
            {/* Left 70%: Financial Relationship Graph */}
            <FinancialRelationshipGraph
              nodes={activeCase.nodes}
              edges={activeCase.edges}
              lastUpdated={activeCase.lastUpdated}
              verified={activeCase.verified}
              selectedNodeId={selectedNodeId}
              highlightLoop={highlightLoop}
              appliedFakePct={appliedFakePct}
              onSelectNode={(id) => {
                setSelectedNodeId(id);
                if (!id) setHighlightLoop(false);
              }}
              onRefresh={handleRefreshGraph}
              onInspectInLedger={handleInspectNodeInLedger}
              onInspectLoop={() => handleViewAnomalyDetails('anom-loop-1')}
            />

            {/* Right 30%: Graph Errors -> Credit Score -> Fraud Scenario Simulator */}
            <div className="flex flex-col gap-4">
              <GraphErrorsPanel
                anomalies={activeCase.anomalies}
                nodes={activeCase.nodes}
                appliedFakePct={appliedFakePct}
                onFocusNode={handleFocusNodeFromPanel}
                onViewDetails={handleViewAnomalyDetails}
              />

              <LoanRiskFactorsPanel
                factors={appliedMetrics.adjustedFactors}
                overallScore={appliedMetrics.adjustedOverallScore}
                riskTier={appliedMetrics.riskTier}
                riskNarrative={appliedMetrics.riskNarrative}
                appliedFakePct={appliedFakePct}
              />

              <FraudSimulatorPanel
                sliderPct={sliderPct}
                appliedFakePct={appliedFakePct}
                previewMetrics={previewMetrics}
                onSliderChange={setSliderPct}
                onRecalculate={handleRecalculateGraph}
                onReset={handleResetSimulation}
              />
            </div>
          </div>
        ) : activeTab === 'ledger' && activeCase ? (
          <EvidenceLedgerView
            records={activeCase.records}
            initialNodeFilter={ledgerNodeFilter}
            onClearNodeFilter={() => setLedgerNodeFilter(null)}
            onLocateNodeInGraph={(nodeId) => handleLocateFromSubView(nodeId, false)}
          />
        ) : activeTab === 'anomalies' && activeCase ? (
          <AnomaliesDetailView
            anomalies={activeCase.anomalies}
            selectedAnomalyId={selectedAnomalyId}
            appliedFakePct={appliedFakePct}
            onSelectAnomaly={setSelectedAnomalyId}
            onUpdateStatus={handleUpdateAnomalyStatus}
            onLocateInGraph={handleLocateFromSubView}
          />
        ) : null}
      </main>
    </div>
  );
}
