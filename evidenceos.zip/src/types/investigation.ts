export type NodeKind = 'business' | 'customer' | 'supplier' | 'invoice' | 'po' | 'bank';

export type EdgeKind = 'transaction' | 'relation' | 'loop';

export type DocumentCategoryKey = 'transactions' | 'orders' | 'invoices' | 'other';

export interface GraphNode {
  id: string;
  label: string;
  sublabel: string;
  type: NodeKind;
  x: number;
  y: number;
  totalVolume: number;
  transactionCount: number;
  riskFlag?: string;
  description: string;
  linkedRecordIds: string[];
  isLoopFocus?: boolean;
  isSimulated?: boolean;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  kind: EdgeKind;
  amount?: number;
  label?: string;
  isSimulated?: boolean;
}

export interface RiskFactor {
  id: 'cashflow' | 'repayment' | 'debt' | 'volatility';
  label: string;
  score: number;
  summary: string;
  detail: string;
}

export interface AnomalyHop {
  step: number;
  timestamp: string;
  from: string;
  to: string;
  amount: number;
  source: string;
  note: string;
}

export interface AnomalyFinding {
  id: string;
  title: string;
  severity: 'critical' | 'high' | 'medium';
  description: string;
  affectedNodeIds: string[];
  hops: AnomalyHop[];
  whatsappEvidence?: {
    sender: string;
    timestamp: string;
    message: string;
    mismatchDetail: string;
  };
  reviewStatus: 'open' | 'confirmed' | 'cleared';
  minFakePct: number;
}

export interface EvidenceRecord {
  id: string;
  refCode: string;
  date: string;
  category: 'Transaction History' | 'Order Copy' | 'Bill / Invoice' | 'WhatsApp Record' | 'Other Documents';
  counterparty: string;
  nodeId: string;
  amount: number;
  direction: 'inflow' | 'outflow' | 'reference';
  sourceFile: string;
  verification: 'verified' | 'mismatch' | 'flagged';
  excerpt: string;
  discrepancyNote?: string;
}

export interface UploadedDocument {
  id: string;
  name: string;
  category: DocumentCategoryKey;
  sizeBytes: number;
  uploadedAt: string;
  extractedCount: number;
  format: string;
  isWhatsApp?: boolean;
}

export interface InvestigationCase {
  id: string;
  businessName: string;
  businessSubtitle: string;
  lastUpdated: string;
  verified: boolean;
  nodes: GraphNode[];
  edges: GraphEdge[];
  baseFactors: RiskFactor[];
  baseOverallScore: number;
  anomalies: AnomalyFinding[];
  records: EvidenceRecord[];
  documents: UploadedDocument[];
}

export interface SimulationMetrics {
  fakeEvidencePct: number;
  riskScoreDelta: number;
  reliabilityDropPct: number;
  flaggedAnomalies: number;
  adjustedOverallScore: number;
  adjustedFactors: RiskFactor[];
  riskTier: 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical Risk';
  riskNarrative: string;
}
