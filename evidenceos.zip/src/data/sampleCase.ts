import type {
  InvestigationCase,
  RiskFactor,
  SimulationMetrics,
  UploadedDocument,
} from '../types/investigation';

export const DEMO_UPLOAD_DOCUMENTS: UploadedDocument[] = [
  {
    id: 'doc-1',
    name: 'SBI_CurrentAccount_Q1_2025.csv',
    category: 'transactions',
    sizeBytes: 248_320,
    uploadedAt: '14 Apr 2025, 10:38 AM',
    extractedCount: 42,
    format: 'CSV',
  },
  {
    id: 'doc-2',
    name: 'PO_Batch_742_to_778.pdf',
    category: 'orders',
    sizeBytes: 1_420_000,
    uploadedAt: '14 Apr 2025, 10:39 AM',
    extractedCount: 11,
    format: 'PDF',
  },
  {
    id: 'doc-3',
    name: 'GST_Invoices_INV4471_4582.pdf',
    category: 'invoices',
    sizeBytes: 982_400,
    uploadedAt: '14 Apr 2025, 10:40 AM',
    extractedCount: 16,
    format: 'PDF',
  },
  {
    id: 'doc-4',
    name: 'WhatsApp_Chat_Suppliers_Apr2025.txt',
    category: 'other',
    sizeBytes: 84_910,
    uploadedAt: '14 Apr 2025, 10:41 AM',
    extractedCount: 19,
    format: 'TXT',
    isWhatsApp: true,
  },
];

export const SAMPLE_CASE: InvestigationCase = {
  id: 'CASE-2025-0414',
  businessName: 'ABC Retail Store',
  businessSubtitle: 'Small Business',
  lastUpdated: '14 Apr 2025, 10:42 AM',
  verified: true,
  baseOverallScore: 68,
  documents: DEMO_UPLOAD_DOCUMENTS,
  nodes: [
    {
      id: 'biz-abc',
      label: 'ABC Retail Store',
      sublabel: '(Small Business)',
      type: 'business',
      x: 380,
      y: 248,
      totalVolume: 28_45_000,
      transactionCount: 64,
      description: 'Primary investigated retail entity. Verified GSTIN & SBI current account ledger across Q1 2025.',
      linkedRecordIds: ['rec-1', 'rec-2', 'rec-3', 'rec-4', 'rec-5', 'rec-6', 'rec-7', 'rec-8'],
    },
    // Customers (top-left)
    {
      id: 'cust-1042',
      label: 'Customer',
      sublabel: 'C-1042',
      type: 'customer',
      x: 196,
      y: 94,
      totalVolume: 4_85_000,
      transactionCount: 9,
      description: 'Repeat wholesale buyer with consistent 15-day NEFT settlement intervals.',
      linkedRecordIds: ['rec-1'],
    },
    {
      id: 'cust-1038',
      label: 'Customer',
      sublabel: 'C-1038',
      type: 'customer',
      x: 112,
      y: 158,
      totalVolume: 6_40_000,
      transactionCount: 7,
      riskFlag: 'Circular loop participant',
      description: 'Counterparty receiving funds indirectly routed back from Supplier S-203 within 5 hours.',
      linkedRecordIds: ['rec-2', 'rec-7'],
      isLoopFocus: true,
    },
    {
      id: 'cust-1021',
      label: 'Customer',
      sublabel: 'C-1021',
      type: 'customer',
      x: 74,
      y: 242,
      totalVolume: 3_12_000,
      transactionCount: 6,
      description: 'Regional retail buyer reconciled across POS receipts and SBI inflows.',
      linkedRecordIds: ['rec-3'],
    },
    // Suppliers (top-right)
    {
      id: 'sup-201',
      label: 'Supplier',
      sublabel: 'S-201',
      type: 'supplier',
      x: 418,
      y: 78,
      totalVolume: 5_20_000,
      transactionCount: 11,
      description: 'Primary FMCG distributor. All GST invoices match bank UTR transfers.',
      linkedRecordIds: ['rec-4'],
    },
    {
      id: 'sup-203',
      label: 'Supplier',
      sublabel: 'S-203',
      type: 'supplier',
      x: 536,
      y: 102,
      totalVolume: 6_95_000,
      transactionCount: 8,
      riskFlag: 'Possible circular routing with C-1038',
      description: 'Wholesale vendor flagged for near-identical same-day outflow matching Customer C-1038 inflows.',
      linkedRecordIds: ['rec-2', 'rec-5', 'rec-7'],
      isLoopFocus: true,
    },
    {
      id: 'sup-207',
      label: 'Supplier',
      sublabel: 'S-207',
      type: 'supplier',
      x: 636,
      y: 162,
      totalVolume: 2_90_000,
      transactionCount: 5,
      description: 'Packaging & logistics vendor with verified e-way bill references.',
      linkedRecordIds: ['rec-6'],
    },
    // Invoices (mid-right)
    {
      id: 'inv-4582',
      label: 'Invoice',
      sublabel: 'INV-4582',
      type: 'invoice',
      x: 678,
      y: 246,
      totalVolume: 2_45_000,
      transactionCount: 1,
      riskFlag: 'WhatsApp amount discrepancy',
      description: 'Tax invoice billed at ₹2,45,000, whereas WhatsApp dispatch chat referenced ₹1,95,000.',
      linkedRecordIds: ['rec-5', 'rec-7'],
    },
    {
      id: 'inv-4471',
      label: 'Invoice',
      sublabel: 'INV-4471',
      type: 'invoice',
      x: 674,
      y: 336,
      totalVolume: 1_84_500,
      transactionCount: 1,
      description: 'Verified merchandise invoice settled via NEFT within credit window.',
      linkedRecordIds: ['rec-4'],
    },
    // Banks (bottom-right)
    {
      id: 'bank-sbi-1',
      label: 'Bank',
      sublabel: 'SBI',
      type: 'bank',
      x: 622,
      y: 422,
      totalVolume: 19_60_000,
      transactionCount: 42,
      description: 'Primary SBI Current Account (•••• 4912) used for vendor settlements and customer collections.',
      linkedRecordIds: ['rec-1', 'rec-4', 'rec-8'],
    },
    {
      id: 'bank-sbi-2',
      label: 'Bank',
      sublabel: 'SBI',
      type: 'bank',
      x: 554,
      y: 486,
      totalVolume: 4_15_000,
      transactionCount: 9,
      description: 'Secondary SBI OD / Linked Reserve Account referenced in credit facility relation.',
      linkedRecordIds: ['rec-8'],
    },
    // Purchase Orders (bottom-left)
    {
      id: 'po-778',
      label: 'PO',
      sublabel: 'PO-778',
      type: 'po',
      x: 92,
      y: 344,
      totalVolume: 1_68_000,
      transactionCount: 1,
      description: 'Purchase order for seasonal dry-goods inventory. Matched with delivery challan.',
      linkedRecordIds: ['rec-6'],
    },
    {
      id: 'po-765',
      label: 'PO',
      sublabel: 'PO-765',
      type: 'po',
      x: 146,
      y: 416,
      totalVolume: 2_10_000,
      transactionCount: 1,
      description: 'Purchase order issued to Supplier S-201; invoiced cleanly under INV-4471.',
      linkedRecordIds: ['rec-4'],
    },
    {
      id: 'po-742',
      label: 'PO',
      sublabel: 'PO-742',
      type: 'po',
      x: 222,
      y: 458,
      totalVolume: 2_45_000,
      transactionCount: 1,
      riskFlag: 'No delivery proof attached',
      description: 'Order copy tied to Supplier S-203 without signed warehouse receipt.',
      linkedRecordIds: ['rec-5'],
    },
  ],
  edges: [
    { id: 'e-c1042', source: 'cust-1042', target: 'biz-abc', kind: 'transaction', amount: 4_85_000, label: 'NEFT Collections' },
    { id: 'e-c1038', source: 'cust-1038', target: 'biz-abc', kind: 'transaction', amount: 6_40_000, label: 'RTGS Credits' },
    { id: 'e-c1021', source: 'cust-1021', target: 'biz-abc', kind: 'transaction', amount: 3_12_000, label: 'UPI / IMPS' },
    { id: 'e-s201', source: 'biz-abc', target: 'sup-201', kind: 'transaction', amount: 5_20_000, label: 'Vendor Payouts' },
    { id: 'e-s203', source: 'biz-abc', target: 'sup-203', kind: 'transaction', amount: 6_95_000, label: 'Settlement' },
    { id: 'e-s207', source: 'biz-abc', target: 'sup-207', kind: 'transaction', amount: 2_90_000, label: 'Logistics' },
    { id: 'e-inv4582', source: 'biz-abc', target: 'inv-4582', kind: 'transaction', amount: 2_45_000, label: 'Billed Invoice' },
    { id: 'e-inv4471', source: 'biz-abc', target: 'inv-4471', kind: 'transaction', amount: 1_84_500, label: 'Settled Invoice' },
    { id: 'e-bank1', source: 'biz-abc', target: 'bank-sbi-1', kind: 'transaction', amount: 19_60_000, label: 'Primary Ledger' },
    { id: 'e-bank2', source: 'biz-abc', target: 'bank-sbi-2', kind: 'relation', label: 'Linked OD Account' },
    { id: 'e-po778', source: 'biz-abc', target: 'po-778', kind: 'transaction', amount: 1_68_000, label: 'Order Issued' },
    { id: 'e-po765', source: 'biz-abc', target: 'po-765', kind: 'transaction', amount: 2_10_000, label: 'Order Issued' },
    { id: 'e-po742', source: 'biz-abc', target: 'po-742', kind: 'transaction', amount: 2_45_000, label: 'Unverified Order' },
    { id: 'e-loop-1', source: 'sup-203', target: 'cust-1038', kind: 'loop', amount: 2_42_000, label: 'Possible Loop' },
  ],
  baseFactors: [
    {
      id: 'cashflow',
      label: 'Cash-flow stability',
      score: 78,
      summary: 'Consistent inflows and outflows',
      detail: '42 verified SBI transactions show steady weekly working-capital velocity with positive closing balances in 11 of 12 weeks.',
    },
    {
      id: 'repayment',
      label: 'Repayment capacity',
      score: 72,
      summary: 'Adequate margin for EMI',
      detail: 'Estimated debt-service coverage ratio of 1.64x based on reconciled net inflows excluding flagged circular transfers.',
    },
    {
      id: 'debt',
      label: 'Debt exposure',
      score: 48,
      summary: 'Existing obligations are moderate',
      detail: 'Linked SBI overdraft utilization averaged 58% over Q1, with two pending vendor credit lines due within 30 days.',
    },
    {
      id: 'volatility',
      label: 'Revenue volatility',
      score: 36,
      summary: 'Some month-to-month fluctuation',
      detail: 'March inflows spiked 34% primarily driven by two high-value transfers from Customer C-1038 that overlap with Supplier S-203 payouts.',
    },
  ],
  anomalies: [
    {
      id: 'anom-loop-1',
      title: 'Possible circular transaction pattern',
      severity: 'critical',
      description:
        'Money appears to move between Supplier S-203 and Customer C-1038 in a circular pattern, which may indicate a potential layering or round-tripping attempt.',
      affectedNodeIds: ['sup-203', 'cust-1038'],
      hops: [
        {
          step: 1,
          timestamp: '08 Apr 2025 · 11:14 AM',
          from: 'ABC Retail Store',
          to: 'Supplier S-203',
          amount: 2_45_000,
          source: 'SBI Statement · UTR40811920',
          note: 'Settled against Invoice INV-4582 & PO-742 without warehouse receipt.',
        },
        {
          step: 2,
          timestamp: '08 Apr 2025 · 01:42 PM',
          from: 'Supplier S-203',
          to: 'Customer C-1038',
          amount: 2_42_000,
          source: 'WhatsApp Export · Counterparty Chat',
          note: 'Chat confirms "forwarded ₹2.42L to C-1038 account after 1.2% adjustment".',
        },
        {
          step: 3,
          timestamp: '08 Apr 2025 · 03:32 PM',
          from: 'Customer C-1038',
          to: 'ABC Retail Store',
          amount: 2_40_000,
          source: 'SBI Statement · UTR40815504',
          note: 'Credited back as fresh sales revenue 4h 18m after original payout.',
        },
      ],
      whatsappEvidence: {
        sender: 'Ramesh (Supplier S-203)',
        timestamp: '08 Apr 2025, 1:39 PM',
        message: 'Got 2.45L on INV-4582. Routing 2.42L back via C-1038 by 3:30 PM as discussed for month-end turnover.',
        mismatchDetail: 'Invoice INV-4582 claims goods delivery of ₹2,45,000, while WhatsApp log references turnover routing.',
      },
      reviewStatus: 'open',
      minFakePct: 0,
    },
    {
      id: 'anom-wa-2',
      title: 'Invoice vs. WhatsApp quote mismatch',
      severity: 'high',
      description:
        'Invoice INV-4582 shows ₹2,45,000 billed to ABC Retail Store, conflicting with the ₹1,95,000 dispatch total recorded in the supplier WhatsApp thread.',
      affectedNodeIds: ['inv-4582', 'sup-203'],
      hops: [
        {
          step: 1,
          timestamp: '07 Apr 2025 · 05:10 PM',
          from: 'Supplier S-203',
          to: 'ABC Retail Store',
          amount: 1_95_000,
          source: 'WhatsApp_Chat_Suppliers_Apr2025.txt',
          note: 'Original dispatch summary sent on WhatsApp.',
        },
        {
          step: 2,
          timestamp: '08 Apr 2025 · 09:30 AM',
          from: 'Supplier S-203',
          to: 'Invoice INV-4582',
          amount: 2_45_000,
          source: 'GST_Invoices_INV4471_4582.pdf',
          note: 'Final invoice inflated by ₹50,000 (+25.6%) with no revised PO.',
        },
      ],
      whatsappEvidence: {
        sender: 'Accounts Desk · ABC Retail',
        timestamp: '07 Apr 2025, 5:14 PM',
        message: 'Confirmed 1.95L stock batch, send updated PDF bill tomorrow morning.',
        mismatchDetail: '₹50,000 unexplained variance between chat confirmation and PDF invoice.',
      },
      reviewStatus: 'open',
      minFakePct: 12,
    },
    {
      id: 'anom-po-3',
      title: 'Unverified purchase order chain (PO-742)',
      severity: 'medium',
      description:
        'PO-742 lacks a corresponding e-way bill or signed goods-received note, increasing vulnerability to fabricated revenue evidence.',
      affectedNodeIds: ['po-742', 'inv-4582'],
      hops: [
        {
          step: 1,
          timestamp: '06 Apr 2025 · 02:20 PM',
          from: 'ABC Retail Store',
          to: 'PO-742',
          amount: 2_45_000,
          source: 'PO_Batch_742_to_778.pdf',
          note: 'Manual PDF order generated without inventory SKU breakdown.',
        },
      ],
      reviewStatus: 'open',
      minFakePct: 25,
    },
    {
      id: 'anom-split-4',
      title: 'Split-transfer structuring across linked accounts',
      severity: 'high',
      description:
        'Simulated fake documentation triggers correlated micro-credits between SBI Linked OD and Customer C-1021 designed to inflate repayment coverage.',
      affectedNodeIds: ['bank-sbi-2', 'cust-1021'],
      hops: [
        {
          step: 1,
          timestamp: '11 Apr 2025 · 04:05 PM',
          from: 'Bank SBI (Linked)',
          to: 'Customer C-1021',
          amount: 98_500,
          source: 'Simulated Audit Injection',
          note: 'Sub-threshold transfer pattern below ₹1L manual audit trigger.',
        },
      ],
      reviewStatus: 'open',
      minFakePct: 45,
    },
  ],
  records: [
    {
      id: 'rec-1',
      refCode: 'UTR40219011',
      date: '02 Apr 2025',
      category: 'Transaction History',
      counterparty: 'Customer C-1042',
      nodeId: 'cust-1042',
      amount: 1_62_000,
      direction: 'inflow',
      sourceFile: 'SBI_CurrentAccount_Q1_2025.csv',
      verification: 'verified',
      excerpt: 'NEFT CR / C-1042 Wholesale Traders / Inv Batch Mar-W4 settled in full.',
    },
    {
      id: 'rec-2',
      refCode: 'UTR40815504',
      date: '08 Apr 2025',
      category: 'Transaction History',
      counterparty: 'Customer C-1038',
      nodeId: 'cust-1038',
      amount: 2_40_000,
      direction: 'inflow',
      sourceFile: 'SBI_CurrentAccount_Q1_2025.csv',
      verification: 'flagged',
      excerpt: 'RTGS CR / C-1038 Enterprises / Received 4h 18m after ₹2.45L payout to S-203.',
      discrepancyNote: 'Matches circular loop window with Supplier S-203 transfer UTR40811920.',
    },
    {
      id: 'rec-3',
      refCode: 'UTR40509182',
      date: '05 Apr 2025',
      category: 'Transaction History',
      counterparty: 'Customer C-1021',
      nodeId: 'cust-1021',
      amount: 1_04_000,
      direction: 'inflow',
      sourceFile: 'SBI_CurrentAccount_Q1_2025.csv',
      verification: 'verified',
      excerpt: 'IMPS CR / C-1021 Retail Mart / Reconciled with POS settlement batch #88.',
    },
    {
      id: 'rec-4',
      refCode: 'INV-4471',
      date: '04 Apr 2025',
      category: 'Bill / Invoice',
      counterparty: 'Supplier S-201',
      nodeId: 'inv-4471',
      amount: 1_84_500,
      direction: 'outflow',
      sourceFile: 'GST_Invoices_INV4471_4582.pdf',
      verification: 'verified',
      excerpt: 'GST Tax Invoice INV-4471 against PO-765. E-way bill #EW918244 verified.',
    },
    {
      id: 'rec-5',
      refCode: 'INV-4582',
      date: '08 Apr 2025',
      category: 'Bill / Invoice',
      counterparty: 'Supplier S-203',
      nodeId: 'inv-4582',
      amount: 2_45_000,
      direction: 'outflow',
      sourceFile: 'GST_Invoices_INV4471_4582.pdf',
      verification: 'mismatch',
      excerpt: 'GST Tax Invoice INV-4582 linked to PO-742. Billed ₹2,45,000 without delivery challan.',
      discrepancyNote: '₹50,000 higher than WhatsApp dispatch quote (₹1,95,000).',
    },
    {
      id: 'rec-6',
      refCode: 'PO-778',
      date: '03 Apr 2025',
      category: 'Order Copy',
      counterparty: 'Supplier S-207',
      nodeId: 'po-778',
      amount: 1_68_000,
      direction: 'reference',
      sourceFile: 'PO_Batch_742_to_778.pdf',
      verification: 'verified',
      excerpt: 'Purchase Order PO-778 for dry-goods packaging crates. Signed receipt archived.',
    },
    {
      id: 'rec-7',
      refCode: 'WA-0408-1339',
      date: '08 Apr 2025',
      category: 'WhatsApp Record',
      counterparty: 'Supplier S-203',
      nodeId: 'sup-203',
      amount: 2_42_000,
      direction: 'reference',
      sourceFile: 'WhatsApp_Chat_Suppliers_Apr2025.txt',
      verification: 'flagged',
      excerpt: '[08/04/25, 1:39 PM] Ramesh (S-203): "Got 2.45L on INV-4582. Routing 2.42L back via C-1038 by 3:30 PM."',
      discrepancyNote: 'Direct documentary indicator of round-tripping between S-203 and C-1038.',
    },
    {
      id: 'rec-8',
      refCode: 'SBI-OD-4912',
      date: '10 Apr 2025',
      category: 'Transaction History',
      counterparty: 'Bank SBI',
      nodeId: 'bank-sbi-2',
      amount: 4_15_000,
      direction: 'reference',
      sourceFile: 'SBI_CurrentAccount_Q1_2025.csv',
      verification: 'verified',
      excerpt: 'Linked Overdraft sweep facility balance & monthly EMI standing instruction.',
    },
  ],
};

export function computeSimulationMetrics(
  baseFactors: RiskFactor[],
  baseOverallScore: number,
  fakeEvidencePct: number
): SimulationMetrics {
  // At 15% fake evidence, matches Screenshot 1 exactly:
  // Risk score change: +8 points, Reliability drop: -12%, Flagged anomalies: 3
  const riskScoreDelta = Math.round(fakeEvidencePct * 0.5333);
  const reliabilityDropPct = Math.round(fakeEvidencePct * 0.8);
  const flaggedAnomalies =
    fakeEvidencePct === 0 ? 1 : Math.min(18, Math.max(1, 1 + Math.ceil(fakeEvidencePct / 7.5)));

  // Higher fake evidence degrades quality factor rings and shifts overall score
  const degradation = fakeEvidencePct / 100;
  const adjustedFactors: RiskFactor[] = baseFactors.map((f) => {
    let multiplier = 0.45;
    if (f.id === 'cashflow') multiplier = 0.42;
    if (f.id === 'repayment') multiplier = 0.38;
    if (f.id === 'debt') multiplier = 0.35;
    if (f.id === 'volatility') multiplier = 0.55;
    const nextScore = Math.max(8, Math.min(98, Math.round(f.score - f.score * degradation * multiplier)));
    return {
      ...f,
      score: nextScore,
    };
  });

  // Note: Overall Risk Score in Screenshot 1 is 68/100 at baseline ("Moderate Risk").
  // When fake evidence is simulated & applied, risk score rises (+delta) toward higher risk,
  // or if applied at 0% stays at baseline 68/100.
  const adjustedOverallScore = Math.min(99, Math.max(12, baseOverallScore + riskScoreDelta));

  let riskTier: SimulationMetrics['riskTier'] = 'Moderate Risk';
  let riskNarrative = 'Business shows good potential with some risk factors to monitor.';

  if (adjustedOverallScore <= 45) {
    riskTier = 'Low Risk';
    riskNarrative = 'Verified transaction graph shows clean settlement flows and low structural risk.';
  } else if (adjustedOverallScore <= 72) {
    riskTier = 'Moderate Risk';
    riskNarrative = 'Business shows good potential with some risk factors to monitor.';
  } else if (adjustedOverallScore <= 85) {
    riskTier = 'High Risk';
    riskNarrative = 'Elevated circular patterns and document discrepancies require manual audit before approval.';
  } else {
    riskTier = 'Critical Risk';
    riskNarrative = 'Severe evidence manipulation risk detected. Loan approval should be paused pending forensic review.';
  }

  return {
    fakeEvidencePct,
    riskScoreDelta,
    reliabilityDropPct,
    flaggedAnomalies,
    adjustedOverallScore,
    adjustedFactors,
    riskTier,
    riskNarrative,
  };
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}
