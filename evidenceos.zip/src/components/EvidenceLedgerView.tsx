import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileText,
  MessageSquareText,
  Search,
  X,
  ArrowUpRight,
} from 'lucide-react';
import type { EvidenceRecord } from '../types/investigation';
import { formatINR } from '../data/sampleCase';

interface EvidenceLedgerViewProps {
  records: EvidenceRecord[];
  initialNodeFilter: string | null;
  onClearNodeFilter: () => void;
  onLocateNodeInGraph: (nodeId: string) => void;
}

const CATEGORIES = [
  'All',
  'Transaction History',
  'Bill / Invoice',
  'Order Copy',
  'WhatsApp Record',
] as const;

export const EvidenceLedgerView: React.FC<EvidenceLedgerViewProps> = ({
  records,
  initialNodeFilter,
  onClearNodeFilter,
  onLocateNodeInGraph,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] =
    useState<(typeof CATEGORIES)[number]>('All');
  const [statusFilter, setStatusFilter] = useState<
    'all' | 'verified' | 'flagged' | 'mismatch'
  >('all');
  const [selectedRecordId, setSelectedRecordId] = useState<string | null>(
    records[0]?.id ?? null
  );

  const filteredRecords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return records.filter((rec) => {
      if (initialNodeFilter && rec.nodeId !== initialNodeFilter) return false;
      if (categoryFilter !== 'All' && rec.category !== categoryFilter) {
        return false;
      }
      if (statusFilter !== 'all' && rec.verification !== statusFilter) {
        return false;
      }
      if (!q) return true;
      return (
        rec.refCode.toLowerCase().includes(q) ||
        rec.counterparty.toLowerCase().includes(q) ||
        rec.sourceFile.toLowerCase().includes(q) ||
        rec.excerpt.toLowerCase().includes(q)
      );
    });
  }, [records, initialNodeFilter, categoryFilter, statusFilter, searchQuery]);

  const selectedRecord =
    filteredRecords.find((r) => r.id === selectedRecordId) ??
    filteredRecords[0] ??
    null;

  const handleExportCsv = () => {
    const headers = [
      'RefCode',
      'Date',
      'Category',
      'Counterparty',
      'AmountINR',
      'Status',
      'SourceFile',
      'Excerpt',
    ];
    const rows = filteredRecords.map((r) => [
      r.refCode,
      r.date,
      r.category,
      r.counterparty,
      String(r.amount),
      r.verification,
      r.sourceFile,
      `"${r.excerpt.replace(/"/g, '""')}"`,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'EvidenceOS_Ledger_Export.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-800/90 bg-[#0b152b] p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[230px] flex-1 sm:flex-none">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search UTR, invoice, WhatsApp..."
              aria-label="Search extracted evidence records"
              className="w-full rounded-lg border border-slate-800 bg-[#0e1933] py-2 pl-9 pr-3 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:border-emerald-400/60 focus:outline-none"
            />
          </div>

          <div
            role="group"
            aria-label="Filter by source category"
            className="flex flex-wrap items-center gap-1 rounded-lg bg-[#0e1933] p-1 border border-slate-800/80"
          >
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  categoryFilter === cat
                    ? 'bg-slate-800 text-slate-50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat === 'Transaction History'
                  ? 'Transactions'
                  : cat === 'Bill / Invoice'
                  ? 'Invoices'
                  : cat === 'WhatsApp Record'
                  ? 'WhatsApp'
                  : cat}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {initialNodeFilter && (
            <button
              type="button"
              onClick={onClearNodeFilter}
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-xs font-medium text-emerald-300 hover:bg-emerald-500/20 whitespace-nowrap"
            >
              Filtered by node
              <X className="h-3.5 w-3.5" />
            </button>
          )}

          <select
            aria-label="Filter by verification status"
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(
                e.target.value as 'all' | 'verified' | 'flagged' | 'mismatch'
              )
            }
            className="rounded-lg border border-slate-800 bg-[#0e1933] px-3 py-2 text-xs font-medium text-slate-200 focus:border-emerald-400/60 focus:outline-none"
          >
            <option value="all">All statuses</option>
            <option value="verified">Verified</option>
            <option value="mismatch">Mismatch</option>
            <option value="flagged">Flagged</option>
          </select>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#122143] px-3.5 py-2 text-xs font-medium text-slate-100 transition-colors hover:border-slate-500 whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Main Split: High-Density Table + Raw Evidence Inspector */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[1fr_360px]">
        <section
          aria-label="Extracted evidence table"
          className="rounded-xl border border-slate-800/90 bg-[#0b152b] overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800 bg-[#091226] text-xs font-medium text-slate-400">
                  <th className="px-4 py-3">Reference</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Source Type</th>
                  <th className="px-4 py-3">Counterparty</th>
                  <th className="px-4 py-3 text-right">Amount</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="px-4 py-10 text-center text-sm text-slate-400"
                    >
                      No extracted evidence matches the current filter.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((rec) => {
                    const isSelected = selectedRecord?.id === rec.id;
                    return (
                      <tr
                        key={rec.id}
                        onClick={() => setSelectedRecordId(rec.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-[#132245]'
                            : 'hover:bg-[#0e1a36]'
                        }`}
                      >
                        <td className="px-4 py-3 font-mono text-xs font-medium text-slate-100 whitespace-nowrap">
                          {rec.refCode}
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-slate-400 tabular-nums whitespace-nowrap">
                          {rec.date}
                        </td>
                        <td className="px-4 py-3 text-slate-300 whitespace-nowrap">
                          {rec.category}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-200 whitespace-nowrap">
                          {rec.counterparty}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-medium text-slate-100 tabular-nums whitespace-nowrap">
                          {formatINR(rec.amount)}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          {rec.verification === 'verified' ? (
                            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              Verified
                            </span>
                          ) : rec.verification === 'mismatch' ? (
                            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-400">
                              <AlertCircle className="h-3.5 w-3.5" />
                              Mismatch
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-400">
                              <AlertCircle className="h-3.5 w-3.5" />
                              Flagged
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Right: Source Excerpt & Discrepancy Inspector */}
        <aside
          aria-label="Evidence source inspector"
          className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-5 flex flex-col justify-between"
        >
          {selectedRecord ? (
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-slate-400">
                  {selectedRecord.category}
                </span>
                <span className="font-mono text-xs text-slate-300">
                  {selectedRecord.refCode}
                </span>
              </div>

              <h2 className="mt-1 font-display text-base font-semibold text-slate-50">
                {selectedRecord.counterparty}
              </h2>

              <div className="mt-3 flex items-baseline justify-between border-y border-slate-800/80 py-3">
                <span className="text-xs text-slate-400">Extracted amount</span>
                <span className="font-mono text-lg font-semibold text-slate-100 tabular-nums">
                  {formatINR(selectedRecord.amount)}
                </span>
              </div>

              <div className="mt-4">
                <div className="flex items-center gap-1.5 text-xs font-medium text-slate-300">
                  {selectedRecord.category === 'WhatsApp Record' ? (
                    <MessageSquareText className="h-3.5 w-3.5 text-emerald-400" />
                  ) : (
                    <FileText className="h-3.5 w-3.5 text-sky-400" />
                  )}
                  Extracted source excerpt
                </div>
                <p className="mt-2 rounded-lg border border-slate-800 bg-[#091226] p-3 font-mono text-xs leading-relaxed text-slate-200">
                  {selectedRecord.excerpt}
                </p>
                <p className="mt-2 text-xs text-slate-400">
                  Source file:{' '}
                  <span className="text-slate-200">{selectedRecord.sourceFile}</span>
                </p>
              </div>

              {selectedRecord.discrepancyNote && (
                <div className="mt-4 rounded-lg border border-rose-500/35 bg-rose-950/15 p-3">
                  <p className="text-xs font-semibold text-rose-300">
                    Inconsistency detected
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-300">
                    {selectedRecord.discrepancyNote}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-slate-400">
              Select a record from the ledger to inspect its raw extracted source.
            </p>
          )}

          {selectedRecord && (
            <button
              type="button"
              onClick={() => onLocateNodeInGraph(selectedRecord.nodeId)}
              className="mt-5 inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-slate-700 bg-[#122143] px-3.5 py-2.5 text-xs font-medium text-slate-100 transition-colors hover:border-emerald-400/50 hover:text-emerald-300"
            >
              Locate counterparty on graph
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          )}
        </aside>
      </div>
    </div>
  );
};
