import React from 'react';
import { FolderPlus, ShieldCheck } from 'lucide-react';

export type WorkspaceTab = 'investigation' | 'upload' | 'ledger' | 'anomalies';

interface TopBarProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
  hasAnalysis: boolean;
  onPrimaryAction: () => void;
}

const NAV_ITEMS: { id: WorkspaceTab; label: string }[] = [
  { id: 'upload', label: 'Upload Documents' },
  { id: 'investigation', label: 'Investigation' },
  { id: 'ledger', label: 'Evidence Ledger' },
  { id: 'anomalies', label: 'Anomalies' },
];

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onTabChange,
  hasAnalysis,
  onPrimaryAction,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-[#070f23]/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={() => onTabChange(hasAnalysis ? 'investigation' : 'upload')}
          className="flex items-center gap-2.5 text-left font-display text-lg font-bold tracking-tight text-slate-50 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 rounded-md"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-400/25">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
          </span>
          EvidenceOS
        </button>

        {/* Zone 2: 4 clean single-line navigation links */}
        <nav
          aria-label="Primary workspace navigation"
          className="hidden md:flex items-center gap-7"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onTabChange(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative py-5 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 rounded-sm ${
                  isActive
                    ? 'text-slate-50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute inset-x-0 bottom-0 h-[2px] bg-emerald-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single primary action button */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onPrimaryAction}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-emerald-400 to-teal-400 px-4 py-2 text-xs sm:text-sm font-semibold text-slate-950 transition-all duration-150 hover:from-emerald-300 hover:to-teal-300 active:scale-[0.98] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070f23]"
          >
            <FolderPlus className="h-4 w-4 shrink-0" aria-hidden="true" />
            {hasAnalysis ? 'New Investigation' : 'Load Sample Case'}
          </button>
        </div>
      </div>

      {/* Compact mobile navigation row */}
      <nav
        aria-label="Mobile workspace navigation"
        className="flex md:hidden items-center gap-1 overflow-x-auto border-t border-slate-800/70 px-4 py-1.5"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onTabChange(item.id)}
              className={`rounded-md px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-slate-800 text-emerald-300'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
