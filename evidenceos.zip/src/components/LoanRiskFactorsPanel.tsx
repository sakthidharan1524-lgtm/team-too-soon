import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import type { RiskFactor, SimulationMetrics } from '../types/investigation';

interface LoanRiskFactorsPanelProps {
  factors: RiskFactor[];
  overallScore: number;
  riskTier: SimulationMetrics['riskTier'];
  riskNarrative: string;
  appliedFakePct: number;
}

function getRingStroke(score: number): string {
  if (score >= 65) return '#34d399'; // Emerald
  if (score >= 45) return '#f59e0b'; // Amber
  return '#f87171'; // Coral / Crimson
}

function getTierStyles(tier: SimulationMetrics['riskTier']): string {
  switch (tier) {
    case 'Low Risk':
      return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    case 'Moderate Risk':
      return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
    case 'High Risk':
      return 'bg-orange-500/15 text-orange-300 border-orange-500/30';
    case 'Critical Risk':
      return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
  }
}

export const LoanRiskFactorsPanel: React.FC<LoanRiskFactorsPanelProps> = ({
  factors,
  overallScore,
  riskTier,
  riskNarrative,
  appliedFakePct,
}) => {
  const [activeFactorId, setActiveFactorId] = useState<string | null>(null);
  const activeFactor = factors.find((f) => f.id === activeFactorId) ?? null;

  const radius = 28;
  const circumference = 2 * Math.PI * radius;

  return (
    <section
      aria-label="Credit Score and Loan Risk Factors"
      className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-4 space-y-4"
    >
      {/* Header + Overall Credit Score Readout */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 shrink-0">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-sm sm:text-base font-semibold text-slate-50 leading-tight">
              Credit Score
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Loan risk &amp; network rating
            </p>
          </div>
        </div>

        <span
          className={`inline-block rounded-md border px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap shrink-0 ${getTierStyles(
            riskTier
          )}`}
        >
          {riskTier}
        </span>
      </div>

      {/* Prominent Score Summary Row */}
      <div className="rounded-lg border border-slate-800/90 bg-[#0e1933] px-3.5 py-3 flex items-center justify-between gap-4">
        <div className="shrink-0">
          <div className="flex items-baseline gap-1">
            <span className="font-mono text-3xl font-bold tracking-tight text-amber-200 tabular-nums">
              {overallScore}
            </span>
            <span className="font-mono text-xs text-slate-400 tabular-nums">
              /100
            </span>
          </div>
          {appliedFakePct > 0 && (
            <p className="mt-0.5 font-mono text-[10px] text-amber-300/90 tabular-nums">
              +{appliedFakePct}% fake sim
            </p>
          )}
        </div>

        <p className="text-xs leading-relaxed text-slate-300">
          {riskNarrative}
        </p>
      </div>

      {/* 2x2 Compact Radial Risk Factor Rings */}
      <div className="grid grid-cols-2 gap-2.5">
        {factors.map((factor) => {
          const strokeColor = getRingStroke(factor.score);
          const dashOffset = circumference * (1 - factor.score / 100);
          const isSelected = activeFactorId === factor.id;

          return (
            <button
              key={factor.id}
              type="button"
              onClick={() =>
                setActiveFactorId(isSelected ? null : factor.id)
              }
              className={`flex items-center gap-2.5 rounded-lg border p-2 text-left transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 ${
                isSelected
                  ? 'border-slate-600 bg-slate-800/70'
                  : 'border-slate-800/80 bg-[#0d1730]/60 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="relative flex h-[54px] w-[54px] items-center justify-center shrink-0">
                <svg
                  viewBox="0 0 68 68"
                  className="h-full w-full -rotate-90"
                  aria-hidden="true"
                >
                  <circle
                    cx="34"
                    cy="34"
                    r={radius}
                    fill="none"
                    stroke="#1e293b"
                    strokeWidth="5.5"
                  />
                  <circle
                    cx="34"
                    cy="34"
                    r={radius}
                    fill="none"
                    stroke={strokeColor}
                    strokeWidth="5.5"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={dashOffset}
                    style={{
                      transition:
                        'stroke-dashoffset 450ms cubic-bezier(0.16, 1, 0.3, 1), stroke 250ms ease',
                    }}
                  />
                </svg>
                <span className="absolute font-mono text-[11px] font-semibold text-slate-100 tabular-nums">
                  {factor.score}
                </span>
              </div>

              <div className="min-w-0">
                <span className="block text-xs font-medium text-slate-100 leading-tight">
                  {factor.label}
                </span>
                <span className="mt-0.5 block text-[11px] leading-snug text-slate-400 line-clamp-2">
                  {factor.summary}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Expandable Factor Detail */}
      {activeFactor && (
        <div className="border-t border-slate-800/80 pt-3 text-xs text-slate-300 flex items-start justify-between gap-2">
          <p className="leading-relaxed">
            <span className="font-semibold text-slate-100">
              {activeFactor.label}:{' '}
            </span>
            {activeFactor.detail}
          </p>
          <button
            type="button"
            onClick={() => setActiveFactorId(null)}
            className="text-slate-400 hover:text-slate-200 whitespace-nowrap shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}
    </section>
  );
};
