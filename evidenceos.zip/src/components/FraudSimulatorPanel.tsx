import React from 'react';
import { Info, RefreshCw, RotateCcw, Settings } from 'lucide-react';
import type { SimulationMetrics } from '../types/investigation';

interface FraudSimulatorPanelProps {
  sliderPct: number;
  appliedFakePct: number;
  previewMetrics: SimulationMetrics;
  onSliderChange: (pct: number) => void;
  onRecalculate: () => void;
  onReset: () => void;
}

const TICK_MARKS = [0, 25, 50, 75, 100];

export const FraudSimulatorPanel: React.FC<FraudSimulatorPanelProps> = ({
  sliderPct,
  appliedFakePct,
  previewMetrics,
  onSliderChange,
  onRecalculate,
  onReset,
}) => {
  const hasPendingChange = sliderPct !== appliedFakePct;

  return (
    <section
      aria-label="Fraud Scenario Simulator"
      className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-4 space-y-3.5"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400 shrink-0">
            <Settings className="h-4 w-4" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-sm sm:text-base font-semibold text-slate-50 leading-tight">
              Fraud Scenario Simulator
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Simulate fake evidence impact
            </p>
          </div>
        </div>

        {appliedFakePct > 0 && (
          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
            Reset
          </button>
        )}
      </div>

      {/* Expected Impact 3-Column Metrics */}
      <div className="rounded-lg border border-slate-800/80 bg-[#0e1933] px-3 py-2.5">
        <p className="text-[11px] font-medium text-slate-400">
          Expected Impact
        </p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <div>
            <span className="block text-[11px] text-slate-400 leading-tight">
              Score delta
            </span>
            <span className="mt-0.5 block font-mono text-xs sm:text-sm font-semibold text-rose-400 tabular-nums">
              {previewMetrics.riskScoreDelta > 0
                ? `+${previewMetrics.riskScoreDelta} pts`
                : '0 pts'}
            </span>
          </div>

          <div>
            <span className="block text-[11px] text-slate-400 leading-tight">
              Reliability
            </span>
            <span className="mt-0.5 block font-mono text-xs sm:text-sm font-semibold text-rose-400 tabular-nums">
              {previewMetrics.reliabilityDropPct > 0
                ? `-${previewMetrics.reliabilityDropPct}%`
                : '0%'}
            </span>
          </div>

          <div>
            <span className="block text-[11px] text-slate-400 leading-tight">
              Anomalies
            </span>
            <span className="mt-0.5 block font-mono text-xs sm:text-sm font-semibold text-rose-400 tabular-nums">
              {previewMetrics.flaggedAnomalies}
            </span>
          </div>
        </div>
      </div>

      {/* Slider Control */}
      <div>
        <div className="flex items-center justify-between text-xs">
          <label
            htmlFor="fake-evidence-slider"
            className="font-medium text-slate-300"
          >
            Simulated fake evidence
          </label>
          <span className="rounded-md bg-amber-500/20 px-2 py-0.5 font-mono text-xs font-semibold text-amber-300 tabular-nums border border-amber-500/30">
            {sliderPct}%
          </span>
        </div>

        <div className="mt-2.5">
          <input
            id="fake-evidence-slider"
            type="range"
            min={0}
            max={100}
            step={5}
            value={sliderPct}
            onChange={(e) => onSliderChange(Number(e.target.value))}
            className="evidence-slider w-full"
            style={{
              background: `linear-gradient(to right, #34d399 0%, #f59e0b ${sliderPct}%, #1e293b ${sliderPct}%, #1e293b 100%)`,
              height: '5px',
              borderRadius: '9999px',
            }}
          />
        </div>

        <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-400 tabular-nums">
          {TICK_MARKS.map((mark) => (
            <button
              key={mark}
              type="button"
              onClick={() => onSliderChange(mark)}
              className={`transition-colors hover:text-slate-100 ${
                sliderPct === mark ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {mark}%
            </button>
          ))}
        </div>
      </div>

      {/* Note + Full-width CTA */}
      <div className="space-y-2.5 pt-0.5">
        <p className="flex items-start gap-2 text-[11px] leading-relaxed text-slate-400">
          <Info className="mt-0.5 h-3.5 w-3.5 text-slate-500 shrink-0" aria-hidden="true" />
          <span>
            Higher fake evidence increases risk score and lowers loan
            eligibility.
          </span>
        </p>

        <button
          type="button"
          onClick={onRecalculate}
          className={`inline-flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs sm:text-sm font-semibold transition-all duration-150 active:scale-[0.98] whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300 ${
            hasPendingChange
              ? 'bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 hover:from-emerald-300 hover:to-teal-300 shadow-lg shadow-emerald-500/15'
              : 'bg-emerald-500/85 text-slate-950 hover:bg-emerald-400'
          }`}
        >
          <RefreshCw className="h-4 w-4 shrink-0" aria-hidden="true" />
          Recalculate graph
        </button>
      </div>
    </section>
  );
};
