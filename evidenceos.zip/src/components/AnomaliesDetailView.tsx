import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  MessageSquareText,
  Network,
  ShieldAlert,
} from 'lucide-react';
import type { AnomalyFinding } from '../types/investigation';
import { formatINR } from '../data/sampleCase';

interface AnomaliesDetailViewProps {
  anomalies: AnomalyFinding[];
  selectedAnomalyId: string | null;
  appliedFakePct: number;
  onSelectAnomaly: (id: string) => void;
  onUpdateStatus: (
    id: string,
    status: AnomalyFinding['reviewStatus']
  ) => void;
  onLocateInGraph: (nodeId: string, highlightLoop: boolean) => void;
}

export const AnomaliesDetailView: React.FC<AnomaliesDetailViewProps> = ({
  anomalies,
  selectedAnomalyId,
  appliedFakePct,
  onSelectAnomaly,
  onUpdateStatus,
  onLocateInGraph,
}) => {
  const visibleAnomalies = anomalies.filter(
    (a) => a.minFakePct <= Math.max(appliedFakePct, 15)
  );
  const current =
    visibleAnomalies.find((a) => a.id === selectedAnomalyId) ??
    visibleAnomalies[0];

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[360px_1fr]">
      {/* Left: Flagged Pattern Queue */}
      <section
        aria-label="Detected anomalies queue"
        className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-4 space-y-2.5"
      >
        <div className="px-1 pb-1">
          <h1 className="font-display text-base font-semibold text-slate-50">
            Detected Patterns &amp; Loops
          </h1>
          <p className="mt-0.5 text-xs text-slate-400">
            {visibleAnomalies.length} findings across documents and WhatsApp logs
          </p>
        </div>

        {visibleAnomalies.map((item) => {
          const isActive = current?.id === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectAnomaly(item.id)}
              className={`w-full rounded-lg border p-3.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 ${
                isActive
                  ? 'border-rose-500/45 bg-[#121e3c]'
                  : 'border-slate-800/80 bg-[#0e1933]/70 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span
                  className={`font-medium ${
                    item.severity === 'critical'
                      ? 'text-rose-400'
                      : item.severity === 'high'
                      ? 'text-amber-400'
                      : 'text-sky-400'
                  }`}
                >
                  {item.severity === 'critical'
                    ? 'Critical pattern'
                    : item.severity === 'high'
                    ? 'High discrepancy'
                    : 'Medium risk'}
                </span>
                <span className="text-slate-400 capitalize">
                  {item.reviewStatus}
                </span>
              </div>
              <p className="mt-1.5 text-sm font-semibold text-slate-100 leading-snug">
                {item.title}
              </p>
              <p className="mt-1 text-xs text-slate-400 line-clamp-2">
                {item.description}
              </p>
            </button>
          );
        })}
      </section>

      {/* Right: Deep Investigation Breakdown */}
      {current && (
        <section
          aria-label="Anomaly investigation details"
          className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-6 space-y-6"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between border-b border-slate-800/80 pb-5">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2 text-xs text-rose-400 font-medium">
                <AlertTriangle className="h-4 w-4" aria-hidden="true" />
                <span>
                  {current.severity === 'critical'
                    ? 'Circular Layering Alert'
                    : 'Documentary Inconsistency'}
                </span>
                <span className="text-slate-600" aria-hidden="true">
                  ·
                </span>
                <span className="text-slate-400">
                  {current.affectedNodeIds.length} nodes linked
                </span>
              </div>
              <h2 className="font-display text-xl font-semibold text-slate-50">
                {current.title}
              </h2>
              <p className="text-sm leading-relaxed text-slate-300">
                {current.description}
              </p>
            </div>

            <button
              type="button"
              onClick={() =>
                onLocateInGraph(
                  current.affectedNodeIds[0] ?? 'sup-203',
                  current.id === 'anom-loop-1'
                )
              }
              className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-[#122143] px-3.5 py-2 text-xs font-medium text-slate-100 transition-colors hover:border-emerald-400/50 hover:text-emerald-300 whitespace-nowrap shrink-0"
            >
              <Network className="h-4 w-4" aria-hidden="true" />
              Highlight on Graph
            </button>
          </div>

          {/* Transaction / Evidence Hop Timeline */}
          <div>
            <h3 className="font-display text-sm font-semibold text-slate-200">
              Reconstructed Transaction Trail
            </h3>

            <div className="mt-3 space-y-3">
              {current.hops.map((hop) => (
                <div
                  key={hop.step}
                  className="grid grid-cols-1 gap-2 rounded-lg border border-slate-800 bg-[#0e1933] p-4 sm:grid-cols-[1fr_auto]"
                >
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="font-mono text-emerald-400 font-semibold">
                        Step {hop.step}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {hop.timestamp}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{hop.source}</span>
                    </div>
                    <p className="mt-1.5 flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-100">
                      <span>{hop.from}</span>
                      <ArrowRight className="h-3.5 w-3.5 text-rose-400" />
                      <span>{hop.to}</span>
                    </p>
                    <p className="mt-1 text-xs text-slate-300">{hop.note}</p>
                  </div>

                  <div className="sm:text-right">
                    <span className="block text-[11px] text-slate-400">
                      Transfer amount
                    </span>
                    <span className="font-mono text-base font-semibold text-slate-100 tabular-nums">
                      {formatINR(hop.amount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Extracted WhatsApp Corroboration */}
          {current.whatsappEvidence && (
            <div className="rounded-lg border border-slate-800 bg-[#091226] p-4 space-y-2.5">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-400">
                  <MessageSquareText className="h-4 w-4" aria-hidden="true" />
                  Corroborating WhatsApp Extract
                </span>
                <span className="font-mono text-slate-400 tabular-nums">
                  {current.whatsappEvidence.timestamp}
                </span>
              </div>
              <p className="text-xs font-medium text-slate-300">
                {current.whatsappEvidence.sender}
              </p>
              <blockquote className="rounded-md bg-[#0e1933] px-3.5 py-2.5 text-sm text-slate-100 italic">
                &ldquo;{current.whatsappEvidence.message}&rdquo;
              </blockquote>
              <p className="text-xs text-rose-300">
                {current.whatsappEvidence.mismatchDetail}
              </p>
            </div>
          )}

          {/* Investigator Disposition Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-4">
            <span className="text-xs font-medium text-slate-400">
              Investigator disposition
            </span>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => onUpdateStatus(current.id, 'open')}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  current.reviewStatus === 'open'
                    ? 'border-slate-500 bg-slate-800 text-slate-100'
                    : 'border-slate-800 bg-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                Under Review
              </button>
              <button
                type="button"
                onClick={() => onUpdateStatus(current.id, 'confirmed')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  current.reviewStatus === 'confirmed'
                    ? 'border-rose-500/60 bg-rose-500/15 text-rose-300'
                    : 'border-slate-800 bg-transparent text-slate-400 hover:text-rose-300'
                }`}
              >
                <ShieldAlert className="h-3.5 w-3.5" />
                Confirm Risk
              </button>
              <button
                type="button"
                onClick={() => onUpdateStatus(current.id, 'cleared')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  current.reviewStatus === 'cleared'
                    ? 'border-emerald-500/60 bg-emerald-500/15 text-emerald-300'
                    : 'border-slate-800 bg-transparent text-slate-400 hover:text-emerald-300'
                }`}
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                Mark Cleared
              </button>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
