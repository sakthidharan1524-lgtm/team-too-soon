import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  FileSpreadsheet,
  Maximize2,
  Minus,
  Plus,
  RefreshCw,
  X,
  ArrowUpRight,
} from 'lucide-react';
import type { GraphEdge, GraphNode, NodeKind } from '../types/investigation';
import { formatINR } from '../data/sampleCase';

interface FinancialRelationshipGraphProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  lastUpdated: string;
  verified: boolean;
  selectedNodeId: string | null;
  highlightLoop: boolean;
  appliedFakePct: number;
  onSelectNode: (nodeId: string | null) => void;
  onRefresh: () => void;
  onInspectInLedger: (nodeId: string) => void;
  onInspectLoop: () => void;
}

const NODE_STYLE: Record<
  NodeKind,
  {
    stroke: string;
    fill: string;
    iconColor: string;
    dotColor: string;
    label: string;
    radius: number;
  }
> = {
  business: {
    stroke: '#34d399',
    fill: '#0f2f2e',
    iconColor: '#6ee7b7',
    dotColor: '#34d399',
    label: 'Business (You)',
    radius: 34,
  },
  customer: {
    stroke: '#34d399',
    fill: '#10292d',
    iconColor: '#6ee7b7',
    dotColor: '#34d399',
    label: 'Customer',
    radius: 21,
  },
  supplier: {
    stroke: '#60a5fa',
    fill: '#112244',
    iconColor: '#93c5fd',
    dotColor: '#3b82f6',
    label: 'Supplier',
    radius: 21,
  },
  invoice: {
    stroke: '#a78bfa',
    fill: '#201a42',
    iconColor: '#c4b5fd',
    dotColor: '#8b5cf6',
    label: 'Invoice',
    radius: 21,
  },
  po: {
    stroke: '#f59e0b',
    fill: '#2d2317',
    iconColor: '#fcd34d',
    dotColor: '#f59e0b',
    label: 'Purchase Order',
    radius: 21,
  },
  bank: {
    stroke: '#2dd4bf',
    fill: '#0f2a33',
    iconColor: '#5eead4',
    dotColor: '#14b8a6',
    label: 'Bank',
    radius: 21,
  },
};

function renderNodeGlyph(type: NodeKind, color: string) {
  switch (type) {
    case 'business':
      return (
        <g transform="translate(-14, -14)" stroke={color} strokeWidth="1.9" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 10.5L5 4.5h18l2 6" />
          <path d="M3 10.5a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0" transform="scale(0.82) translate(1.2, 2)" />
          <rect x="5" y="12.5" width="18" height="11" rx="1.5" />
          <path d="M11 23.5v-6h6v6" />
        </g>
      );
    case 'customer':
      return (
        <g transform="translate(-9, -9)" fill={color}>
          <circle cx="9" cy="6" r="3.3" />
          <path d="M3.2 15.8c0-2.9 2.6-4.8 5.8-4.8s5.8 1.9 5.8 4.8" />
        </g>
      );
    case 'supplier':
      return (
        <g transform="translate(-9, -9)" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M2.5 15.5V8l4.5 2.5V8l4.5 2.5V5h4v10.5z" />
          <path d="M6 15.5v-2.2M10 15.5v-2.2M13.5 15.5v-2.2" />
        </g>
      );
    case 'invoice':
      return (
        <g transform="translate(-9, -9)" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4.5 2.5h6.5l3.5 3.5v9.5a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-12a1 1 0 0 1 1-1z" />
          <path d="M7 9h5M7 12h4" />
        </g>
      );
    case 'po':
      return (
        <g transform="translate(-9, -9)" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 2.5l6 3.3v6.4L9 15.5l-6-3.3V5.8z" />
          <path d="M3 5.8L9 9l6-3.2M9 9v6.5" />
        </g>
      );
    case 'bank':
      return (
        <g transform="translate(-9, -9)" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M2.5 7L9 3l6.5 4z" />
          <path d="M4.5 7v6.5M9 7v6.5M13.5 7v6.5M2.5 14.5h13" />
        </g>
      );
  }
}

export const FinancialRelationshipGraph: React.FC<FinancialRelationshipGraphProps> = ({
  nodes,
  edges,
  lastUpdated,
  verified,
  selectedNodeId,
  highlightLoop,
  appliedFakePct,
  onSelectNode,
  onRefresh,
  onInspectInLedger,
  onInspectLoop,
}) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [activeTypeFilter, setActiveTypeFilter] = useState<NodeKind | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const dragOrigin = useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  const nodeMap = useMemo(() => {
    const map = new Map<string, GraphNode>();
    nodes.forEach((n) => map.set(n.id, n));
    return map;
  }, [nodes]);

  const selectedNode = selectedNodeId ? nodeMap.get(selectedNodeId) ?? null : null;

  const handleRefreshClick = () => {
    setIsRefreshing(true);
    onRefresh();
    window.setTimeout(() => setIsRefreshing(false), 550);
  };

  const handleZoom = (delta: number) => {
    setZoom((prev) => Math.max(0.75, Math.min(1.65, Number((prev + delta).toFixed(2)))));
  };

  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setActiveTypeFilter(null);
  };

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if ((e.target as HTMLElement).closest('[data-graph-interactive="true"]')) return;
    setIsDragging(true);
    dragOrigin.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    const dx = e.clientX - dragOrigin.current.x;
    const dy = e.clientY - dragOrigin.current.y;
    setPan({
      x: Math.max(-140, Math.min(140, dragOrigin.current.panX + dx)),
      y: Math.max(-120, Math.min(120, dragOrigin.current.panY + dy)),
    });
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  // Dedicated circular loop cluster coordinates (bottom-center, centered at x=380)
  const loopSupplierPos = { x: 324, y: 452 };
  const loopCustomerPos = { x: 436, y: 452 };

  return (
    <section
      aria-label="Financial Relationship Graph"
      className="flex h-full flex-col rounded-xl border border-slate-800/90 bg-[#0b152b] overflow-hidden"
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 px-5 py-3.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <FileSpreadsheet className="h-4 w-4 text-slate-300 shrink-0" aria-hidden="true" />
          <h2 className="font-display text-sm sm:text-base font-semibold text-slate-100 truncate">
            Financial Relationship Graph
          </h2>
          {verified && appliedFakePct < 30 && (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-400 whitespace-nowrap shrink-0">
              <span aria-hidden="true" className="text-slate-600">·</span>
              <Check className="h-3.5 w-3.5" aria-hidden="true" />
              Verified
            </span>
          )}
          {appliedFakePct >= 30 && (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-400 whitespace-nowrap shrink-0">
              <span aria-hidden="true" className="text-slate-600">·</span>
              <AlertCircle className="h-3.5 w-3.5" aria-hidden="true" />
              Simulated Risk ({appliedFakePct}%)
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-400 shrink-0">
          <span className="font-mono tabular-nums whitespace-nowrap">
            Last updated: {lastUpdated}
          </span>
          <button
            type="button"
            onClick={handleRefreshClick}
            title="Re-verify graph relationships"
            aria-label="Refresh graph"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-[#101c38] text-slate-300 transition-colors hover:border-slate-700 hover:text-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70"
          >
            <RefreshCw
              className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`}
              aria-hidden="true"
            />
          </button>
        </div>
      </div>

      {/* Main Interactive SVG Canvas */}
      <div className="relative flex-1 min-h-[470px] sm:min-h-[540px] bg-[radial-gradient(circle_at_50%_46%,rgba(30,58,138,0.16),rgba(9,17,36,0.96)_72%)] select-none overflow-hidden">
        {/* Selected Node Forensic Overlay (appears cleanly when a node is clicked) */}
        {selectedNode && (
          <div className="absolute left-4 top-4 z-20 w-[290px] max-w-[calc(100%-2rem)] rounded-lg border border-slate-700/90 bg-[#0d1933]/95 p-3.5 shadow-xl backdrop-blur-md">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-medium text-slate-400">
                  {NODE_STYLE[selectedNode.type].label}
                </p>
                <h3 className="font-display text-sm font-semibold text-slate-100 truncate">
                  {selectedNode.label} {selectedNode.sublabel}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onSelectNode(null)}
                aria-label="Close node inspector"
                className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-slate-100"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            <p className="mt-2 text-xs leading-relaxed text-slate-300">
              {selectedNode.description}
            </p>

            {selectedNode.riskFlag && (
              <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-rose-400">
                <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                {selectedNode.riskFlag}
              </p>
            )}

            <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-800 pt-2.5 text-xs">
              <div>
                <span className="block text-slate-400">Linked volume</span>
                <span className="font-mono font-medium text-slate-100 tabular-nums">
                  {formatINR(selectedNode.totalVolume)}
                </span>
              </div>
              <div>
                <span className="block text-slate-400">Records</span>
                <span className="font-mono font-medium text-slate-100 tabular-nums">
                  {selectedNode.transactionCount} entries
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onInspectInLedger(selectedNode.id)}
              className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-slate-700 bg-[#132245] px-3 py-1.5 text-xs font-medium text-slate-100 transition-colors hover:border-emerald-400/50 hover:text-emerald-300"
            >
              Inspect linked evidence
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>
        )}

        <svg
          viewBox="0 0 760 560"
          className={`h-full w-full ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          role="img"
          aria-label="Interactive financial relationship network centered on ABC Retail Store"
        >
          <defs>
            <marker
              id="arrow-green"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#34d399" />
            </marker>
            <marker
              id="arrow-blue"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#60a5fa" />
            </marker>
            <marker
              id="arrow-violet"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#a78bfa" />
            </marker>
            <marker
              id="arrow-amber"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#f59e0b" />
            </marker>
            <marker
              id="arrow-teal"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#2dd4bf" />
            </marker>
            <marker
              id="arrow-loop"
              viewBox="0 0 10 10"
              refX="7.5"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 9 5 L 0 8.5 z" fill="#f87171" />
            </marker>

            <radialGradient id="biz-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#34d399" stopOpacity="0.32" />
              <stop offset="100%" stopColor="#34d399" stopOpacity="0" />
            </radialGradient>
          </defs>

          <g
            transform={`translate(${380 + pan.x}, ${280 + pan.y}) scale(${zoom}) translate(-380, -280)`}
            style={{ transition: isDragging ? 'none' : 'transform 180ms cubic-bezier(0.16, 1, 0.3, 1)' }}
          >
            {/* Subtle ambient halo behind hub node */}
            <circle cx={380} cy={248} r={82} fill="url(#biz-glow)" />

            {/* Hub-to-node transaction & relation edges */}
            {edges
              .filter((e) => e.kind !== 'loop')
              .map((edge) => {
                const src = nodeMap.get(edge.source);
                const tgt = nodeMap.get(edge.target);
                if (!src || !tgt) return null;

                const dx = tgt.x - src.x;
                const dy = tgt.y - src.y;
                const dist = Math.hypot(dx, dy) || 1;
                const rSrc = NODE_STYLE[src.type].radius + 5;
                const rTgt = NODE_STYLE[tgt.type].radius + 7;

                const x1 = src.x + (dx / dist) * rSrc;
                const y1 = src.y + (dy / dist) * rSrc;
                const x2 = tgt.x - (dx / dist) * rTgt;
                const y2 = tgt.y - (dy / dist) * rTgt;

                const accentNode = src.type === 'business' ? tgt : src;
                const strokeColor = NODE_STYLE[accentNode.type].stroke;
                const markerId =
                  accentNode.type === 'customer'
                    ? 'url(#arrow-green)'
                    : accentNode.type === 'supplier'
                    ? 'url(#arrow-blue)'
                    : accentNode.type === 'invoice'
                    ? 'url(#arrow-violet)'
                    : accentNode.type === 'po'
                    ? 'url(#arrow-amber)'
                    : 'url(#arrow-teal)';

                const isDimmed =
                  (activeTypeFilter &&
                    src.type !== activeTypeFilter &&
                    tgt.type !== activeTypeFilter &&
                    src.type !== 'business' &&
                    tgt.type !== 'business') ||
                  (activeTypeFilter && accentNode.type !== activeTypeFilter);

                const isHighlighted =
                  selectedNodeId === src.id ||
                  selectedNodeId === tgt.id ||
                  (highlightLoop && (src.isLoopFocus || tgt.isLoopFocus));

                const isCompromised =
                  appliedFakePct >= 25 &&
                  (accentNode.id === 'inv-4582' || accentNode.id === 'po-742');

                return (
                  <line
                    key={edge.id}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={isCompromised ? '#f87171' : strokeColor}
                    strokeWidth={isHighlighted ? 2.4 : 1.55}
                    strokeOpacity={isDimmed ? 0.16 : isHighlighted ? 0.95 : 0.72}
                    strokeDasharray={
                      edge.kind === 'relation' || isCompromised ? '5 4' : undefined
                    }
                    markerEnd={isCompromised ? 'url(#arrow-loop)' : markerId}
                  />
                );
              })}

            {/* Secondary simulated fraud loop when fake evidence >= 40% */}
            {appliedFakePct >= 40 && (
              <g opacity={0.9}>
                <path
                  d="M 616 402 Q 664 322 674 268"
                  fill="none"
                  stroke="#f87171"
                  strokeWidth="1.8"
                  strokeDasharray="5 4"
                  className="animate-loop-flow"
                  markerEnd="url(#arrow-loop)"
                />
                <path
                  d="M 228 442 Q 375 390 538 474"
                  fill="none"
                  stroke="#f87171"
                  strokeWidth="1.6"
                  strokeDasharray="5 4"
                  className="animate-loop-flow"
                  markerEnd="url(#arrow-loop)"
                />
              </g>
            )}

            {/* Vertical dotted anchor from Business Hub down into Possible Loop cluster */}
            <line
              x1={380}
              y1={324}
              x2={380}
              y2={372}
              stroke="#64748b"
              strokeWidth="1.2"
              strokeDasharray="3 4"
              opacity={0.7}
            />

            {/* Possible Loop Sub-Cluster (Bottom Center) */}
            <g
              data-graph-interactive="true"
              onClick={onInspectLoop}
              className="cursor-pointer group"
            >
              {/* Soft danger glow when highlighted */}
              {highlightLoop && (
                <ellipse
                  cx={380}
                  cy={452}
                  rx={102}
                  ry={68}
                  fill="rgba(239, 68, 68, 0.08)"
                  stroke="rgba(248, 113, 113, 0.25)"
                  strokeWidth="1"
                />
              )}

              {/* Upper red dashed arc S-203 -> C-1038 */}
              <path
                d={`M ${loopSupplierPos.x + 8} ${loopSupplierPos.y - 26} C ${loopSupplierPos.x + 28} ${loopSupplierPos.y - 68}, ${loopCustomerPos.x - 28} ${loopCustomerPos.y - 68}, ${loopCustomerPos.x - 8} ${loopCustomerPos.y - 26}`}
                fill="none"
                stroke="#f87171"
                strokeWidth={highlightLoop ? 2.4 : 1.8}
                strokeDasharray="6 5"
                className="animate-loop-flow"
                markerEnd="url(#arrow-loop)"
              />

              {/* Lower red dashed arc C-1038 -> S-203 */}
              <path
                d={`M ${loopCustomerPos.x - 6} ${loopCustomerPos.y + 44} C ${loopCustomerPos.x - 28} ${loopCustomerPos.y + 84}, ${loopSupplierPos.x + 28} ${loopSupplierPos.y + 84}, ${loopSupplierPos.x + 6} ${loopSupplierPos.y + 44}`}
                fill="none"
                stroke="#f87171"
                strokeWidth={highlightLoop ? 2.4 : 1.8}
                strokeDasharray="6 5"
                className="animate-loop-flow"
                markerEnd="url(#arrow-loop)"
              />

              {/* "Possible Loop" callout box */}
              <g transform="translate(334, 374)">
                <rect
                  x="0"
                  y="0"
                  width="92"
                  height="22"
                  rx="4"
                  fill="#2a1622"
                  stroke="#ef4444"
                  strokeOpacity="0.6"
                  strokeWidth="1"
                />
                <text
                  x="46"
                  y="14.5"
                  textAnchor="middle"
                  fill="#fca5a5"
                  fontSize="10.5"
                  fontWeight="600"
                >
                  Possible Loop
                </text>
              </g>

              {/* Center exclamation icon */}
              <g transform="translate(380, 456)">
                <circle r="11" fill="#ef4444" fillOpacity="0.92" />
                <text
                  y="4.5"
                  textAnchor="middle"
                  fill="#0b152b"
                  fontSize="13"
                  fontWeight="700"
                >
                  !
                </text>
              </g>

              {/* Loop Node: Supplier S-203 */}
              <g
                transform={`translate(${loopSupplierPos.x}, ${loopSupplierPos.y})`}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectNode('sup-203');
                }}
              >
                <circle
                  r={21}
                  fill={NODE_STYLE.supplier.fill}
                  stroke={selectedNodeId === 'sup-203' ? '#f87171' : NODE_STYLE.supplier.stroke}
                  strokeWidth={selectedNodeId === 'sup-203' ? 2.6 : 1.8}
                />
                {renderNodeGlyph('supplier', NODE_STYLE.supplier.iconColor)}
                <text y="36" textAnchor="middle" fill="#cbd5e1" fontSize="10.5" fontWeight="500">
                  Supplier
                </text>
                <text y="49" textAnchor="middle" fill="#94a3b8" fontSize="10" className="font-mono">
                  S-203
                </text>
              </g>

              {/* Loop Node: Customer C-1038 */}
              <g
                transform={`translate(${loopCustomerPos.x}, ${loopCustomerPos.y})`}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectNode('cust-1038');
                }}
              >
                <circle
                  r={21}
                  fill={NODE_STYLE.customer.fill}
                  stroke={selectedNodeId === 'cust-1038' ? '#f87171' : NODE_STYLE.customer.stroke}
                  strokeWidth={selectedNodeId === 'cust-1038' ? 2.6 : 1.8}
                />
                {renderNodeGlyph('customer', NODE_STYLE.customer.iconColor)}
                <text y="36" textAnchor="middle" fill="#cbd5e1" fontSize="10.5" fontWeight="500">
                  Customer
                </text>
                <text y="49" textAnchor="middle" fill="#94a3b8" fontSize="10" className="font-mono">
                  C-1038
                </text>
              </g>
            </g>

            {/* Primary Network Nodes */}
            {nodes.map((node) => {
              const style = NODE_STYLE[node.type];
              const isSelected = selectedNodeId === node.id;
              const isDimmed =
                activeTypeFilter !== null &&
                node.type !== activeTypeFilter &&
                node.type !== 'business';
              const isLoopMember = highlightLoop && node.isLoopFocus;

              return (
                <g
                  key={node.id}
                  data-graph-interactive="true"
                  transform={`translate(${node.x}, ${node.y})`}
                  onClick={() => onSelectNode(isSelected ? null : node.id)}
                  className="cursor-pointer"
                  opacity={isDimmed ? 0.25 : 1}
                >
                  {/* Selection / focus halo */}
                  {(isSelected || isLoopMember) && (
                    <circle
                      r={style.radius + 7}
                      fill="none"
                      stroke={isLoopMember ? '#f87171' : style.stroke}
                      strokeWidth="1.6"
                      strokeOpacity="0.65"
                      strokeDasharray={isLoopMember ? '4 3' : undefined}
                    />
                  )}

                  {/* Node outer circle */}
                  <circle
                    r={style.radius}
                    fill={style.fill}
                    stroke={isSelected ? '#f8fafc' : style.stroke}
                    strokeWidth={node.type === 'business' ? 2.6 : 1.8}
                  />

                  {/* Icon glyph */}
                  {renderNodeGlyph(node.type, style.iconColor)}

                  {/* Risk indicator dot on flagged nodes when fake evidence is elevated */}
                  {node.riskFlag && appliedFakePct >= 15 && (
                    <circle
                      cx={style.radius - 3}
                      cy={-style.radius + 3}
                      r={4.5}
                      fill="#ef4444"
                      stroke="#0b152b"
                      strokeWidth="1.5"
                    />
                  )}

                  {/* Node labels */}
                  <text
                    y={style.radius + 15}
                    textAnchor="middle"
                    fill={node.type === 'business' ? '#f8fafc' : '#cbd5e1'}
                    fontSize={node.type === 'business' ? '12.5' : '10.5'}
                    fontWeight={node.type === 'business' ? '600' : '500'}
                  >
                    {node.label}
                  </text>
                  <text
                    y={style.radius + 29}
                    textAnchor="middle"
                    fill="#94a3b8"
                    fontSize={node.type === 'business' ? '10.5' : '10'}
                    className={node.type === 'business' ? '' : 'font-mono'}
                  >
                    {node.sublabel}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>

        {/* Bottom-right Zoom & Fit Controls (matching Screenshot 1) */}
        <div
          aria-label="Graph zoom controls"
          className="absolute bottom-3.5 right-3.5 z-10 flex items-center divide-x divide-slate-800 rounded-lg border border-slate-800 bg-[#0d1832]/90 backdrop-blur-sm overflow-hidden"
        >
          <button
            type="button"
            onClick={() => handleZoom(0.15)}
            aria-label="Zoom in"
            className="flex h-9 w-9 items-center justify-center text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
          >
            <Plus className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => handleZoom(-0.15)}
            aria-label="Zoom out"
            className="flex h-9 w-9 items-center justify-center text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
          >
            <Minus className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={handleResetView}
            aria-label="Reset graph zoom and position"
            className="flex h-9 w-9 items-center justify-center text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Bottom Interactive Legend (matching Screenshot 1 two-row legend) */}
      <div className="border-t border-slate-800/80 bg-[#091226] px-5 py-3 space-y-2">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
          {(Object.keys(NODE_STYLE) as NodeKind[]).map((kind) => {
            const item = NODE_STYLE[kind];
            const isActive = activeTypeFilter === kind;
            return (
              <button
                key={kind}
                type="button"
                onClick={() => setActiveTypeFilter(isActive ? null : kind)}
                className={`inline-flex items-center gap-1.5 text-xs transition-opacity whitespace-nowrap ${
                  activeTypeFilter && !isActive
                    ? 'opacity-40 hover:opacity-80'
                    : 'opacity-100'
                } ${isActive ? 'text-white font-medium' : 'text-slate-300 hover:text-white'}`}
              >
                <span
                  className="h-2.5 w-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: item.dotColor }}
                  aria-hidden="true"
                />
                {item.label}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-slate-400">
          <span className="inline-flex items-center gap-2 whitespace-nowrap">
            <span className="h-[1.5px] w-5 bg-slate-400 inline-block" aria-hidden="true" />
            Transaction
          </span>
          <span className="inline-flex items-center gap-2 whitespace-nowrap">
            <span
              className="h-0 w-5 border-t-[1.5px] border-dashed border-slate-400 inline-block"
              aria-hidden="true"
            />
            Relation
          </span>
          <span className="inline-flex items-center gap-2 text-rose-300 whitespace-nowrap">
            <span
              className="h-0 w-5 border-t-[1.5px] border-dashed border-rose-400 inline-block"
              aria-hidden="true"
            />
            Unusual Loop
          </span>
          {activeTypeFilter && (
            <button
              type="button"
              onClick={() => setActiveTypeFilter(null)}
              className="ml-auto text-xs text-emerald-400 hover:text-emerald-300 underline-offset-2 hover:underline"
            >
              Clear filter
            </button>
          )}
        </div>
      </div>
    </section>
  );
};
