import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import type { AnomalyFinding, GraphNode } from '../types/investigation';

interface GraphErrorsPanelProps {
  anomalies: AnomalyFinding[];
  nodes: GraphNode[];
  appliedFakePct: number;
  onFocusNode: (nodeId: string) => void;
  onViewDetails: (anomalyId: string) => void;
}

export const GraphErrorsPanel: React.FC<GraphErrorsPanelProps> = ({
  anomalies,
  nodes,
  appliedFakePct,
  onFocusNode,
  onViewDetails,
}) => {
  const activeAnomalies = anomalies.filter(
    (a) => a.minFakePct <= appliedFakePct && a.reviewStatus !== 'cleared'
  );
  const primaryAnomaly = activeAnomalies[0] ?? anomalies[0];
  const secondaryAnomalies = activeAnomalies.slice(1);

  const affectedNodes = primaryAnomaly.affectedNodeIds
    .map((id) => nodes.find((n) => n.id === id))
    .filter((n): n is GraphNode => Boolean(n));

  return (
    <section
      aria-label="Graph Errors and Loops"
      className="rounded-xl border border-slate-800/90 bg-[#0b152b] p-4 space-y-3.5"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400 shrink-0">
            <AlertTriangle className="h-4 w-4" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-sm sm:text-base font-semibold text-slate-50 leading-tight">
              Graph Errors &amp; Loops
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Detected issues in the relationship graph
            </p>
          </div>
        </div>
        <span className="font-mono text-xs font-semibold text-rose-400 tabular-nums whitespace-nowrap shrink-0">
          {activeAnomalies.length} active
        </span>
      </div>

      {/* Primary Circular Pattern Alert */}
      <div className="rounded-lg border border-rose-500/35 bg-rose-950/15 p-3">
        <div className="flex items-start gap-2">
          <AlertTriangle
            className="mt-0.5 h-4 w-4 text-rose-400 shrink-0"
            aria-hidden="true"
          />
          <div className="min-w-0">
            <h3 className="text-xs font-semibold text-rose-300 leading-snug">
              {primaryAnomaly.title}
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-300">
              {primaryAnomaly.description}
            </p>
          </div>
        </div>
      </div>

      {/* Affected Nodes + View details CTA */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-medium text-slate-300">Affected nodes</span>
          <span className="inline-flex items-center gap-0.5 font-mono font-semibold text-rose-400 tabular-nums">
            {affectedNodes.length}
            <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {affectedNodes.map((node) => (
            <button
              key={node.id}
              type="button"
              onClick={() => onFocusNode(node.id)}
              className="flex items-center gap-2 rounded-lg border border-slate-800 bg-[#0e1933] px-2.5 py-1.5 text-left text-xs text-slate-200 transition-colors hover:border-slate-600 hover:bg-[#132245] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 min-w-0"
            >
              <span
                className={`h-2 w-2 rounded-full shrink-0 ${
                  node.type === 'supplier'
                    ? 'bg-blue-400'
                    : node.type === 'customer'
                    ? 'bg-emerald-400'
                    : 'bg-violet-400'
                }`}
                aria-hidden="true"
              />
              <span className="truncate font-medium">
                {node.label}{' '}
                <span className="font-mono text-slate-400">
                  {node.sublabel}
                </span>
              </span>
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => onViewDetails(primaryAnomaly.id)}
          className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-slate-700/80 bg-[#132245] px-3 py-2 text-xs font-medium text-slate-100 transition-colors hover:border-slate-500 hover:bg-[#192b54] whitespace-nowrap"
        >
          View details
          <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </div>

      {/* Other Issues compact footer */}
      <div className="border-t border-slate-800/80 pt-3">
        {secondaryAnomalies.length === 0 ? (
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck
              className="h-4 w-4 text-emerald-400 shrink-0"
              aria-hidden="true"
            />
            <span>No other critical errors found</span>
          </div>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-amber-300">Other Issues</span>
              <span className="font-mono text-xs font-semibold text-amber-300 tabular-nums">
                +{secondaryAnomalies.length}
              </span>
            </div>
            {secondaryAnomalies.slice(0, 2).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onViewDetails(item.id)}
                className="block w-full truncate text-left text-xs text-slate-300 hover:text-amber-200 transition-colors"
              >
                · {item.title}
              </button>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
