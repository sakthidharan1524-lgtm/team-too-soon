import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpCircle,
  CheckCircle2,
  ChevronRight,
  CloudUpload,
  FileSpreadsheet,
  FileText,
  Folder,
  Play,
  Receipt,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  MessageSquareText,
} from 'lucide-react';
import type {
  DocumentCategoryKey,
  EvidenceRecord,
  UploadedDocument,
} from '../types/investigation';
import { DEMO_UPLOAD_DOCUMENTS } from '../data/sampleCase';
import { formatFileSize, parseUploadedFile } from '../utils/documentParser';

interface UploadWorkspaceProps {
  documents: UploadedDocument[];
  hasActiveAnalysis: boolean;
  isAnalyzing: boolean;
  analysisStage: string;
  onAddDocuments: (docs: UploadedDocument[], records: EvidenceRecord[]) => void;
  onRemoveDocument: (docId: string) => void;
  onLoadDemoBundle: () => void;
  onStartAnalysis: () => void;
  onOpenInvestigation: () => void;
}

const CATEGORY_SLOTS: {
  key: DocumentCategoryKey;
  label: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  iconBoxClass: string;
}[] = [
  {
    key: 'transactions',
    label: 'Transaction History',
    hint: 'Bank CSV, ledger statements',
    icon: ArrowUpCircle,
    iconBoxClass: 'bg-sky-500/15 text-sky-400',
  },
  {
    key: 'orders',
    label: 'Order Copy',
    hint: 'Purchase orders, delivery challans',
    icon: FileSpreadsheet,
    iconBoxClass: 'bg-emerald-500/15 text-emerald-400',
  },
  {
    key: 'invoices',
    label: 'Bill / Invoice',
    hint: 'GST bills, vendor invoices',
    icon: Receipt,
    iconBoxClass: 'bg-violet-500/15 text-violet-400',
  },
  {
    key: 'other',
    label: 'WhatsApp & Other Documents',
    hint: 'WhatsApp .txt exports, chat screenshots',
    icon: Folder,
    iconBoxClass: 'bg-amber-500/15 text-amber-400',
  },
];

export const UploadWorkspace: React.FC<UploadWorkspaceProps> = ({
  documents,
  hasActiveAnalysis,
  isAnalyzing,
  analysisStage,
  onAddDocuments,
  onRemoveDocument,
  onLoadDemoBundle,
  onStartAnalysis,
  onOpenInvestigation,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [targetCategory, setTargetCategory] = useState<
    DocumentCategoryKey | undefined
  >(undefined);
  const [expandedCategory, setExpandedCategory] =
    useState<DocumentCategoryKey | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFilesSelected = async (
    fileList: FileList | null,
    explicitCategory?: DocumentCategoryKey
  ) => {
    if (!fileList || fileList.length === 0) return;
    const newDocs: UploadedDocument[] = [];
    const newRecords: EvidenceRecord[] = [];

    for (const file of Array.from(fileList)) {
      if (file.size > 10 * 1024 * 1024) continue;
      const parsed = await parseUploadedFile(file, explicitCategory);
      newDocs.push(parsed.doc);
      newRecords.push(...parsed.extractedRecords);
    }

    if (newDocs.length > 0) {
      onAddDocuments(newDocs, newRecords);
    }
  };

  const triggerFilePicker = (category?: DocumentCategoryKey) => {
    setTargetCategory(category);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    void handleFilesSelected(e.dataTransfer.files);
  };

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[380px_1fr] items-stretch">
      {/* Left Column: Upload Documents Panel (Faithful to Screenshot 2) */}
      <section
        aria-label="Upload Documents"
        className="flex flex-col rounded-xl border border-slate-800/90 bg-[#0b152b] p-5"
      >
        <div className="flex items-center gap-2.5">
          <CloudUpload
            className="h-6 w-6 text-teal-400 shrink-0"
            aria-hidden="true"
          />
          <h1 className="font-display text-lg font-semibold text-slate-50">
            Upload Documents
          </h1>
        </div>

        <p className="mt-1.5 text-xs sm:text-sm leading-relaxed text-slate-400">
          Upload transaction history, order copies, bills, WhatsApp exports or
          other supporting files.
        </p>

        {/* Hidden native file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".pdf,.csv,.jpg,.jpeg,.png,.txt"
          className="hidden"
          onChange={(e) => void handleFilesSelected(e.target.files, targetCategory)}
        />

        {/* Drag & Drop Zone */}
        <div
          role="button"
          tabIndex={0}
          onClick={() => triggerFilePicker(undefined)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              triggerFilePicker(undefined);
            }
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragOver(true);
          }}
          onDragLeave={() => setIsDragOver(false)}
          onDrop={handleDrop}
          className={`mt-5 flex flex-col items-center justify-center rounded-xl border border-dashed px-4 py-8 text-center transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 ${
            isDragOver
              ? 'border-emerald-400 bg-emerald-500/10'
              : 'border-slate-700/80 bg-[#0e1933]/80 hover:border-slate-500 hover:bg-[#111e3d]'
          }`}
        >
          <CloudUpload
            className="h-9 w-9 text-teal-400/90"
            aria-hidden="true"
          />
          <p className="mt-3 text-sm font-medium text-slate-100">
            Drag &amp; drop files here
            <br />
            or click to browse
          </p>
          <p className="mt-2 text-xs text-slate-400">
            Supports: PDF, CSV, JPG, PNG, TXT (Max 10MB each)
          </p>
        </div>

        {/* Categorized Evidence Slots (Faithful to Screenshot 2) */}
        <div className="mt-4 space-y-2.5 flex-1">
          {CATEGORY_SLOTS.map((slot) => {
            const Icon = slot.icon;
            const slotDocs = documents.filter((d) => d.category === slot.key);
            const isExpanded = expandedCategory === slot.key;

            return (
              <div
                key={slot.key}
                className="rounded-lg border border-slate-800/90 bg-[#0e1933] overflow-hidden"
              >
                <div className="flex items-center justify-between gap-2 px-3 py-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      if (slotDocs.length > 0) {
                        setExpandedCategory(isExpanded ? null : slot.key);
                      } else {
                        triggerFilePicker(slot.key);
                      }
                    }}
                    className="flex flex-1 items-center gap-3 text-left min-w-0 focus-visible:outline-none"
                  >
                    <span
                      className={`flex h-8 w-8 items-center justify-center rounded-md shrink-0 ${slot.iconBoxClass}`}
                    >
                      <Icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <span className="block text-sm font-medium text-slate-100 truncate">
                        {slot.label}
                      </span>
                      <span className="block text-[11px] text-slate-400 truncate">
                        {slotDocs.length > 0
                          ? `${slotDocs.length} file${slotDocs.length > 1 ? 's' : ''} attached`
                          : slot.hint}
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => triggerFilePicker(slot.key)}
                    aria-label={`Add file to ${slot.label}`}
                    className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-800 hover:text-slate-100 shrink-0"
                  >
                    <ChevronRight
                      className={`h-4 w-4 transition-transform ${
                        isExpanded ? 'rotate-90' : ''
                      }`}
                    />
                  </button>
                </div>

                {isExpanded && slotDocs.length > 0 && (
                  <div className="border-t border-slate-800/80 bg-[#0a1328] px-3 py-2 space-y-1.5">
                    {slotDocs.map((doc) => (
                      <div
                        key={doc.id}
                        className="flex items-center justify-between gap-2 text-xs"
                      >
                        <div className="flex items-center gap-2 min-w-0 text-slate-300">
                          {doc.isWhatsApp ? (
                            <MessageSquareText className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <FileText className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                          )}
                          <span className="truncate">{doc.name}</span>
                          <span className="font-mono text-[11px] text-slate-500 shrink-0 tabular-nums">
                            {formatFileSize(doc.sizeBytes)}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => onRemoveDocument(doc.id)}
                          aria-label={`Remove ${doc.name}`}
                          className="p-1 text-slate-500 hover:text-rose-400 transition-colors shrink-0"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Sample Bundle Shortcut when empty */}
        {documents.length === 0 && (
          <button
            type="button"
            onClick={onLoadDemoBundle}
            className="mt-4 w-full rounded-lg border border-slate-700/80 bg-[#0f1c3a] px-3.5 py-2 text-xs font-medium text-slate-300 transition-colors hover:border-emerald-400/50 hover:text-emerald-300"
          >
            Load sample bundle ({DEMO_UPLOAD_DOCUMENTS.length} files · ABC Retail Store)
          </button>
        )}

        {/* Primary CTA: Start Analysis (Faithful to Screenshot 2) */}
        <button
          type="button"
          disabled={isAnalyzing}
          onClick={onStartAnalysis}
          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-emerald-400 to-teal-400 px-4 py-3 text-sm font-semibold text-slate-950 transition-all duration-150 hover:from-emerald-300 hover:to-teal-300 active:scale-[0.99] disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300"
        >
          <Play className="h-4 w-4 fill-current shrink-0" aria-hidden="true" />
          {isAnalyzing
            ? 'Analyzing Evidence...'
            : documents.length > 0
            ? `Start Analysis (${documents.length} files)`
            : 'Start Analysis'}
        </button>
      </section>

      {/* Right Column: 3 Empty / Extraction Preview Cards (Faithful to Screenshot 2) */}
      <div className="flex flex-col gap-5">
        {isAnalyzing ? (
          <section
            aria-live="polite"
            className="flex flex-1 flex-col justify-center rounded-xl border border-emerald-500/30 bg-[#0b152b] p-8"
          >
            <div className="max-w-md space-y-4">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400">
                  <ShieldCheck className="h-5 w-5 animate-pulse" />
                </span>
                <div>
                  <h2 className="font-display text-lg font-semibold text-slate-50">
                    Building Financial Intelligence
                  </h2>
                  <p className="text-xs text-emerald-300">{analysisStage}</p>
                </div>
              </div>

              <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-emerald-400 to-teal-400 animate-pulse" />
              </div>

              <div className="space-y-2 pt-2 text-xs text-slate-400">
                <p>· Extracting structured transactions &amp; WhatsApp references</p>
                <p>· Cross-verifying GST invoices against purchase orders</p>
                <p>· Scanning graph topology for circular layering loops</p>
              </div>
            </div>
          </section>
        ) : (
          <>
            {/* Panel 1: Graph Errors & Loops */}
            <section className="flex flex-1 items-center gap-5 rounded-xl border border-slate-800/90 bg-[#0b152b] p-6 sm:p-8">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/15 text-rose-400 shrink-0">
                <AlertTriangle className="h-8 w-8" aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-xl sm:text-2xl font-semibold text-amber-200/95">
                  Graph Errors &amp; Loops
                </h2>
                <p className="mt-1.5 text-sm sm:text-base text-slate-400">
                  {hasActiveAnalysis
                    ? 'Circular transaction pattern detected between Supplier S-203 and Customer C-1038.'
                    : 'No analysis yet'}
                </p>
              </div>
              {hasActiveAnalysis && (
                <button
                  type="button"
                  onClick={onOpenInvestigation}
                  className="hidden sm:inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#111e3d] px-3.5 py-2 text-xs font-medium text-emerald-300 hover:border-emerald-400/50 whitespace-nowrap shrink-0"
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  View Dashboard
                </button>
              )}
            </section>

            {/* Panel 2: Credit Score */}
            <section className="flex flex-1 items-center gap-5 rounded-xl border border-slate-800/90 bg-[#0b152b] p-6 sm:p-8">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400 shrink-0">
                <ShieldCheck className="h-8 w-8" aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-xl sm:text-2xl font-semibold text-slate-50">
                  Credit Score
                </h2>
                <p className="mt-1.5 text-sm sm:text-base text-slate-400">
                  {hasActiveAnalysis
                    ? 'Analysis ready · Credit Score and 4 loan risk factors calculated.'
                    : documents.length > 0
                    ? `${documents.length} document${documents.length > 1 ? 's' : ''} staged — click Start Analysis to compute credit score.`
                    : 'Upload documents to view credit score & risk factors'}
                </p>
              </div>
            </section>

            {/* Panel 3: Fraud Scenario Simulator */}
            <section className="flex flex-1 items-center gap-5 rounded-xl border border-slate-800/90 bg-[#0b152b] p-6 sm:p-8">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-500/15 text-indigo-300 shrink-0">
                <SlidersHorizontal className="h-8 w-8" aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-xl sm:text-2xl font-semibold text-slate-50">
                  Fraud Scenario Simulator
                </h2>
                <p className="mt-1.5 text-sm sm:text-base text-slate-400">
                  {hasActiveAnalysis
                    ? 'Interactive fake-evidence stress testing enabled on the Investigation board.'
                    : 'Upload documents to enable simulation'}
                </p>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
};
